import { useState, useEffect, useRef, type FormEvent, type KeyboardEvent } from 'react';
import {
  Bot,
  User,
  Send,
  Plus,
  Trash2,
  Sparkles,
  Loader2,
  AlertCircle,
  Eye,
  Layers,
  Waves,
  TrendingUp,
  ShieldCheck,
  Cpu,
  Image as ImageIcon,
  Mic,
  ArrowRight,
} from 'lucide-react';
import { chatApi, getErrorMessage } from '../../services/api.ts';
import { useLanguage } from '../../context/LanguageContext.tsx';
import type { ChatSession, ChatMessage, ChatProviderStatus } from '../../types/index.ts';

interface ChatViewProps {
  onSelectModelTool?: (modelId: string) => void;
  externalActiveSessionId?: number | null;
  onSessionsLoaded?: (sessions: ChatSession[]) => void;
  initialQuery?: string;
  onClearInitialQuery?: () => void;
}

export function ChatView({
  onSelectModelTool,
  externalActiveSessionId,
  onSessionsLoaded,
  initialQuery,
  onClearInitialQuery,
}: ChatViewProps) {
  const { t } = useLanguage();
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSession, setActiveSession] = useState<ChatSession | null>(null);
  const [providerStatus, setProviderStatus] = useState<ChatProviderStatus | null>(null);
  const [inputContent, setInputContent] = useState(initialQuery || '');
  const [isLoadingSessions, setIsLoadingSessions] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showImageGuideModal, setShowImageGuideModal] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Load chat sessions and provider status on mount
  useEffect(() => {
    let isMounted = true;
    async function loadInitialData() {
      try {
        const [list, pStatus] = await Promise.all([
          chatApi.listSessions(),
          chatApi.getProviderStatus().catch(() => null),
        ]);
        if (isMounted) {
          if (pStatus) setProviderStatus(pStatus);
          setSessions(list);
          if (onSessionsLoaded) onSessionsLoaded(list);

          if (list.length > 0) {
            const target = externalActiveSessionId
              ? list.find((s) => s.id === externalActiveSessionId) || list[0]
              : list[0];
            setActiveSession(target);
          } else {
            // Automatically create first consultation session
            const newSession = await chatApi.createSession('General Agricultural Consultation');
            setSessions([newSession]);
            setActiveSession(newSession);
            if (onSessionsLoaded) onSessionsLoaded([newSession]);
          }
        }
      } catch (err) {
        if (isMounted) setError(getErrorMessage(err));
      } finally {
        if (isMounted) setIsLoadingSessions(false);
      }
    }

    loadInitialData();
    return () => {
      isMounted = false;
    };
  }, []);

  // Sync external session change from sidebar
  useEffect(() => {
    if (externalActiveSessionId && sessions.length > 0) {
      const match = sessions.find((s) => s.id === externalActiveSessionId);
      if (match) setActiveSession(match);
    }
  }, [externalActiveSessionId, sessions]);

  // Handle pre-filled initial query if provided (e.g. from Dashboard)
  useEffect(() => {
    if (initialQuery) {
      setInputContent(initialQuery);
      if (onClearInitialQuery) onClearInitialQuery();
      textareaRef.current?.focus();
    }
  }, [initialQuery, onClearInitialQuery]);

  // Auto-scroll messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeSession?.messages, isSending]);

  const handleCreateSession = async () => {
    try {
      const count = sessions.length + 1;
      const title = t(`কৃষি পরামর্শ সেশন #${count}`, `Consultation Session #${count}`);
      const newSession = await chatApi.createSession(title);
      const updated = [newSession, ...sessions];
      setSessions(updated);
      setActiveSession(newSession);
      if (onSessionsLoaded) onSessionsLoaded(updated);
      setError(null);
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const handleDeleteSession = async (e: React.MouseEvent, sessionId: number) => {
    e.stopPropagation();
    if (!window.confirm(t('এই চ্যাট সেশনটি স্থায়ীভাবে মুছে ফেলতে চান?', 'Permanently delete this chat session?'))) {
      return;
    }
    try {
      await chatApi.deleteSession(sessionId);
      const remaining = sessions.filter((s) => s.id !== sessionId);
      setSessions(remaining);
      if (onSessionsLoaded) onSessionsLoaded(remaining);

      if (activeSession?.id === sessionId) {
        if (remaining.length > 0) {
          setActiveSession(remaining[0]);
        } else {
          const fresh = await chatApi.createSession('New Consultation');
          setSessions([fresh]);
          setActiveSession(fresh);
          if (onSessionsLoaded) onSessionsLoaded([fresh]);
        }
      }
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const handleSendMessage = async (e?: FormEvent) => {
    if (e) e.preventDefault();
    const content = inputContent.trim();
    if (!content || !activeSession || isSending) return;

    setInputContent('');
    setIsSending(true);
    setError(null);

    // Optimistic user message addition
    const optimisticUserMsg: ChatMessage = {
      role: 'user',
      content,
      timestamp: new Date().toISOString(),
    };
    const updatedMessages = [...(activeSession.messages || []), optimisticUserMsg];
    setActiveSession({
      ...activeSession,
      messages: updatedMessages,
    });

    try {
      const updatedSession = await chatApi.postMessage(activeSession.id, content);
      setActiveSession(updatedSession);
      // Update in sessions list
      const updatedList = sessions.map((s) => (s.id === updatedSession.id ? updatedSession : s));
      setSessions(updatedList);
      if (onSessionsLoaded) onSessionsLoaded(updatedList);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setIsSending(false);
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const quickPrompts = [
    {
      label: t('টমেটো পাতার দাগ নির্ণয়', 'Diagnose tomato spots'),
      prompt: t(
        'আমার টমেটো গাছের পাতায় বাদামি দাগ ও হলুদ বলয় দেখা দিয়েছে। এর সম্ভাব্য কারণ ও সমাধান কী?',
        'I have brown circular spots on my tomato leaves with yellow rings. What is the diagnosis?'
      ),
      modelId: 'tomato_disease_v3',
    },
    {
      label: t('উচ্চ নাইট্রোজেনে ফসল সুপারিশ', 'Recommend for high Nitrogen'),
      prompt: t(
        'আমার মাটির পরীক্ষায় নাইট্রোজেন=৯০, ফসফরাস=৪২, পটাশিয়াম=৪৩ এবং পিএইচ=৬.৫। কোন ফসল চাষ করা উচিত?',
        'My soil test shows N=90, P=42, K=43, pH=6.5. What crop is recommended for this soil?'
      ),
      modelId: 'crop_recommendation',
    },
    {
      label: t('টমেটোর বর্তমান পাইকারি দর', 'Tomato wholesale price baseline'),
      prompt: t(
        'বাংলাদেশে বর্তমান টমেটোর সাপ্তাহিক পাইকারি বাজারদর ও বেঞ্চমার্ক কত?',
        'What is the current weekly wholesale market price benchmark for tomatoes in Bangladesh?'
      ),
      modelId: 'tomato_price',
    },
    {
      label: t('বন্যা ঝুঁকির পরিমাপকসমূহ', 'Flood risk scoring factors'),
      prompt: t(
        'উচ্চতা, নদীর নৈকট্য ও পানি নিষ্কাশন ক্ষমতা কীভাবে বন্যা ঝুঁকি নির্ধারণ করে?',
        'How do elevation, river proximity, and drainage density impact flood susceptibility?'
      ),
      modelId: 'flood_susceptibility',
    },
  ];

  return (
    <div className="bg-forest-950 rounded-3xl border border-forest-800 shadow-xl overflow-hidden flex flex-col h-[750px] max-h-[85vh]">
      
      {/* Top Session & Truthful Provider Status Bar */}
      <div className="bg-forest-900/90 border-b border-forest-800/80 px-4 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
        
        {/* Left: Active Session Title & Session Chips */}
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none py-1 min-w-0 max-w-full sm:max-w-[60%]">
          <button
            type="button"
            onClick={handleCreateSession}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-forest-800 hover:bg-forest-750 text-gold-300 border border-gold-400/30 text-xs font-bengali font-bold transition-colors cursor-pointer shrink-0"
            title={t('নতুন সেশন তৈরি করুন', 'Create New Session')}
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t('নতুন চ্যাট', 'New Chat')}</span>
          </button>

          <div className="h-5 w-px bg-forest-800 mx-1 shrink-0" />

          {sessions.map((s) => {
            const isActive = activeSession?.id === s.id;
            return (
              <div
                key={s.id}
                onClick={() => setActiveSession(s)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium cursor-pointer transition-colors whitespace-nowrap shrink-0 group ${
                  isActive
                    ? 'bg-forest-800 text-gold-300 border border-gold-400/40 shadow-xs'
                    : 'bg-forest-950/70 text-sage-300 border border-forest-850 hover:bg-forest-850 hover:text-cream-100'
                }`}
              >
                <span className="font-bengali truncate max-w-[130px] sm:max-w-[180px]">
                  {s.title || t('কৃষি পরামর্শ', 'Consultation')}
                </span>
                <button
                  type="button"
                  onClick={(e) => handleDeleteSession(e, s.id)}
                  className="opacity-0 group-hover:opacity-100 p-0.5 rounded hover:text-red-400 transition-opacity cursor-pointer text-sage-400"
                  aria-label="Delete session"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Right: Truthful Provider Status Badge & Dedicated Model Shortcuts */}
        <div className="flex items-center gap-2.5 shrink-0">
          
          {/* Truthful Provider Disclosure Badge */}
          {providerStatus && (
            <div
              className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-medium border shadow-2xs transition-colors ${
                providerStatus.is_external_llm_configured
                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                  : 'bg-forest-950/90 text-gold-300 border-forest-750'
              }`}
              title={
                providerStatus.disclaimer ||
                providerStatus.description ||
                'আমাদের কৃষি AI সহায়ক ইঞ্জিন'
              }
            >
              {providerStatus.is_external_llm_configured ? (
                <>
                  <Sparkles className="w-3 h-3 text-emerald-400 animate-pulse shrink-0" />
                  <span className="font-semibold">{providerStatus.mode_label}</span>
                  {providerStatus.model && (
                    <span className="text-[10px] text-emerald-400 hidden sm:inline">
                      ({providerStatus.model})
                    </span>
                  )}
                </>
              ) : (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 text-gold-400 shrink-0" />
                  <span className="font-semibold font-bengali">
                    {t('লোকাল এগ্রোনমিক ইঞ্জিন', 'Local Advisory Engine')}
                  </span>
                  <span className="text-[10px] text-sage-400 font-mono hidden md:inline">
                    (Verified Rules)
                  </span>
                </>
              )}
            </div>
          )}

          {/* Model Launch Shortcuts */}
          {onSelectModelTool && (
            <div className="hidden lg:flex items-center gap-1.5 shrink-0 text-xs border-l border-forest-800 pl-2">
              <button
                type="button"
                onClick={() => onSelectModelTool('tomato_disease_v3')}
                className="p-1.5 rounded-lg bg-forest-950 border border-forest-800 hover:border-gold-400/50 text-gold-300 transition-colors"
                title="Tomato Disease Vision Scanner"
              >
                <Eye className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onSelectModelTool('crop_recommendation')}
                className="p-1.5 rounded-lg bg-forest-950 border border-forest-800 hover:border-gold-400/50 text-gold-300 transition-colors"
                title="Precision Crop Recommendation"
              >
                <Layers className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onSelectModelTool('flood_susceptibility')}
                className="p-1.5 rounded-lg bg-forest-950 border border-forest-800 hover:border-gold-400/50 text-gold-300 transition-colors"
                title="Flood Risk Scoring"
              >
                <Waves className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onSelectModelTool('tomato_price')}
                className="p-1.5 rounded-lg bg-forest-950 border border-forest-800 hover:border-gold-400/50 text-gold-300 transition-colors"
                title="Market Pricing Forecaster"
              >
                <TrendingUp className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Messages Thread Container (Dark Botanical Styling) */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 bg-gradient-to-b from-forest-950 via-[#071810] to-forest-950">
        {isLoadingSessions ? (
          <div className="flex flex-col items-center justify-center h-full text-sage-400">
            <Loader2 className="w-7 h-7 animate-spin text-gold-400 mb-2" />
            <p className="text-xs font-bengali">{t('পরামর্শ সেশনে যুক্ত হওয়া হচ্ছে...', 'Connecting to consultation session...')}</p>
          </div>
        ) : activeSession?.messages?.length === 0 ? (
          <div className="text-center py-16 text-sage-300 max-w-lg mx-auto">
            <div className="w-14 h-14 rounded-2xl bg-forest-900 border border-forest-750 flex items-center justify-center text-gold-400 mx-auto mb-4 shadow-md">
              <Bot className="w-7 h-7" />
            </div>
            <h3 className="font-bengali font-bold text-lg text-cream-50 mb-1.5">
              {t('আমাদের কৃষি AI সহকারীর সাথে পরামর্শ শুরু করুন', 'Begin Your Agronomic Consultation')}
            </h3>
            <p className="font-bengali text-xs sm:text-sm text-sage-400 leading-relaxed mb-6">
              {t(
                'টমেটো বা ধানের পাতার রোগ, মাটির এনপিকে উপাদান অনুযায়ী ফসল নির্ধারণ, বন্যা ঝুঁকি বা বাজারদর নিয়ে যেকোনো প্রশ্ন বাংলায় বা ইংরেজিতে লিখুন।',
                'Ask questions about foliar pathology, soil nutrient suitability, regional crop yields, or wholesale market prices.'
              )}
            </p>

            {/* Quick Starter Suggestions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-left">
              {quickPrompts.map((qp, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setInputContent(qp.prompt);
                    textareaRef.current?.focus();
                  }}
                  className="p-3 rounded-xl bg-forest-900/80 hover:bg-forest-850 border border-forest-800 hover:border-gold-400/40 text-left transition-colors cursor-pointer group"
                >
                  <p className="font-bengali font-semibold text-xs text-cream-100 group-hover:text-gold-300 flex items-center justify-between">
                    <span>{qp.label}</span>
                    <ArrowRight className="w-3 h-3 text-sage-500 group-hover:translate-x-0.5 transition-transform" />
                  </p>
                  <p className="font-bengali text-[11px] text-sage-400 truncate mt-1">
                    {qp.prompt}
                  </p>
                </button>
              ))}
            </div>
          </div>
        ) : (
          activeSession?.messages?.map((msg, idx) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={idx}
                className={`flex items-start gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-forest-900 border border-forest-750 text-gold-400 flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`rounded-2xl p-4 max-w-xl text-xs sm:text-sm leading-relaxed ${
                    isUser
                      ? 'bg-forest-800 text-cream-50 rounded-tr-xs border border-forest-700 shadow-md font-bengali'
                      : 'bg-forest-900/90 text-cream-100 border border-forest-800 rounded-tl-xs shadow-md font-bengali'
                  }`}
                >
                  {isUser ? (
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  ) : (
                    <div>{renderFormattedMessage(msg.content)}</div>
                  )}

                  {/* Tool Invocations Badge if any tools were executed */}
                  {!isUser && (msg.metadata?.tool_invocations?.length ?? 0) > 0 && (
                    <div className="mt-3 pt-2.5 border-t border-forest-800/80 space-y-2">
                      {msg.metadata?.tool_invocations?.map((ti: any, tIdx: number) => (
                        <div
                          key={tIdx}
                          className="bg-forest-950 p-2.5 rounded-xl border border-forest-800 text-[11px] text-cream-200"
                        >
                          <div className="flex items-center gap-1.5 font-semibold text-gold-300 mb-1">
                            <Cpu className="w-3.5 h-3.5 text-gold-400" />
                            <span>Executed Tool: {ti.tool}</span>
                          </div>
                          {ti.result?.caveat && (
                            <p className="text-[10px] text-sage-400 italic mt-0.5">
                              {ti.result.caveat}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Timestamp & Provider Disclosure */}
                  <div
                    className={`mt-2.5 pt-1.5 flex items-center justify-between text-[10px] ${
                      isUser ? 'text-sage-300 border-t border-forest-700/60' : 'text-sage-400 border-t border-forest-800/80'
                    }`}
                  >
                    <span>
                      {isUser ? (
                        t('আপনি', 'You')
                      ) : msg.provider === 'gemini' ? (
                        <span className="inline-flex items-center gap-1 text-emerald-300 font-medium">
                          <Sparkles className="w-2.5 h-2.5 text-emerald-400" /> Google Gemini AI
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-gold-300">
                          <ShieldCheck className="w-2.5 h-2.5 text-gold-400" /> {t('লোকাল এগ্রোনমিক ইঞ্জিন', 'Local Advisory Engine')}
                        </span>
                      )}
                    </span>
                    <span>
                      {new Date(msg.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-forest-800 border border-forest-700 text-cream-50 flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })
        )}

        {isSending && (
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-forest-900 border border-forest-750 text-gold-400 flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-forest-900 border border-forest-800 rounded-2xl rounded-tl-xs p-3.5 shadow-xs flex items-center gap-2 text-xs text-sage-300 font-bengali">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-gold-400" />
              <span>{t('কৃষি জ্ঞানভাণ্ডার ও গবেষণা মডেল বিশ্লেষণ করা হচ্ছে...', 'Analyzing query against agronomic knowledge base & research tools...')}</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Bar */}
      <div className="px-4 py-2 bg-forest-900/60 border-t border-forest-800/80 overflow-x-auto scrollbar-none flex items-center gap-2 shrink-0">
        <span className="text-[11px] font-semibold text-gold-400 flex items-center gap-1 shrink-0 font-bengali">
          <Sparkles className="w-3 h-3 text-gold-400" /> {t('পরামর্শ:', 'Suggested:')}
        </span>
        {quickPrompts.map((qp, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => {
              setInputContent(qp.prompt);
              textareaRef.current?.focus();
            }}
            className="text-[11px] bg-forest-950/80 border border-forest-800 text-cream-100 hover:border-gold-400 hover:text-gold-300 px-2.5 py-1 rounded-lg whitespace-nowrap transition-colors cursor-pointer shrink-0 font-bengali"
          >
            {qp.label}
          </button>
        ))}
      </div>

      {/* Error Alert */}
      {error && (
        <div className="px-4 py-2 bg-red-950/40 border-t border-red-500/30 flex items-center gap-2 text-xs text-red-300 font-bengali">
          <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />
          <span className="truncate">{error}</span>
        </div>
      )}

      {/* Message Input Composer (Modern ChatGPT style with Dark Botanical theme) */}
      <form onSubmit={handleSendMessage} className="p-3 sm:p-4 bg-forest-950 border-t border-forest-800/80 shrink-0">
        <div className="relative bg-forest-900/90 rounded-2xl border border-forest-750 focus-within:border-gold-400/80 focus-within:ring-2 focus-within:ring-gold-400/20 transition-all p-2 flex flex-col gap-2 shadow-lg">
          
          <textarea
            ref={textareaRef}
            rows={2}
            value={inputContent}
            onChange={(e) => setInputContent(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isLoadingSessions || !activeSession}
            placeholder={
              isLoadingSessions
                ? t('পরামর্শ সেশনে যুক্ত হওয়া হচ্ছে...', 'Connecting to consultation session...')
                : t(
                    'এখানে আপনার কৃষি বিষয়ক প্রশ্ন লিখুন... (Enter চাপলে পাঠানো হবে, Shift+Enter নতুন লাইন)',
                    'Ask an agricultural query... (Press Enter to send, Shift+Enter for newline)'
                  )
            }
            className="w-full bg-transparent border-none text-xs sm:text-sm text-cream-50 placeholder:text-sage-400 focus:outline-none resize-none px-2 py-1 max-h-32 disabled:opacity-50 font-bengali"
          />

          <div className="flex items-center justify-between pt-1 border-t border-forest-800/60">
            
            {/* Shortcuts: Image model guide & Voice note */}
            <div className="flex items-center gap-1 sm:gap-2">
              
              {/* Image Upload Shortcut -> Opens educational guide or jumps to vision tool */}
              <button
                type="button"
                onClick={() => setShowImageGuideModal(true)}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-forest-950 hover:bg-forest-850 text-sage-300 hover:text-gold-300 border border-forest-800 text-xs font-bengali transition-colors cursor-pointer"
                title={t('পাতার ছবি দিয়ে রোগ নির্ণয় করুন', 'Diagnose leaf diseases with image models')}
              >
                <ImageIcon className="w-3.5 h-3.5 text-gold-400" />
                <span className="hidden sm:inline">{t('ছবি স্ক্যান', 'Scan Image')}</span>
              </button>

              {/* Disabled Voice input indicator with clear explanatory tooltip */}
              <button
                type="button"
                disabled
                className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-forest-950/40 text-sage-500 border border-forest-800/40 text-xs font-bengali cursor-not-allowed opacity-60"
                title={t('ভয়েস ইনপুট পরবর্তী আপডেটে যুক্ত হবে', 'Voice input coming in future update')}
              >
                <Mic className="w-3.5 h-3.5" />
                <span className="hidden md:inline text-[10px]">{t('ভয়েস (শীঘ্রই)', 'Voice')}</span>
              </button>
            </div>

            {/* Send Button */}
            <div className="flex items-center gap-2">
              <span className="hidden sm:inline text-[10px] font-mono text-sage-500">
                Enter ↵
              </span>
              <button
                type="submit"
                disabled={!inputContent.trim() || isLoadingSessions || !activeSession || isSending}
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-gold-500 to-gold-400 hover:from-gold-400 hover:to-gold-300 text-forest-950 text-xs font-bengali font-bold transition-all shadow-md cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                aria-label="Send message"
              >
                {isSending ? (
                  <Loader2 className="w-4 h-4 animate-spin text-forest-950" />
                ) : (
                  <>
                    <span>{t('পাঠান', 'Send')}</span>
                    <Send className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>

          </div>

        </div>

        <p className="text-[10px] text-sage-400 mt-2 text-center flex items-center justify-center gap-1.5 flex-wrap font-bengali">
          <span>{t('আমাদের কৃষি AI সহকারী', 'Amader Krishi AI Assistant')}</span>
          <span>•</span>
          <span>
            {providerStatus?.is_external_llm_configured
              ? 'Google Gemini AI Connected'
              : t('লোকাল এগ্রোনমিক ইঞ্জিন (অফলাইন নিরাপদ)', 'Local Advisory Mode (Offline Safe)')}
          </span>
          <span>•</span>
          <span>{t('দ্বিভাষিক (বাংলা / English)', 'Bilingual Support')}</span>
        </p>
      </form>

      {/* Image Upload Guide Modal */}
      {showImageGuideModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-950/70 backdrop-blur-sm animate-fade-in-up">
          <div className="bg-forest-900 border border-forest-750 rounded-3xl p-6 max-w-md w-full text-cream-50 shadow-2xl">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-gold-400/20 text-gold-400 flex items-center justify-center">
                <ImageIcon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bengali font-bold text-base text-cream-100">
                  {t('ছবি বিশ্লেষণ কনসোল', 'Image Pathology Consoles')}
                </h3>
                <p className="text-[11px] text-sage-400">
                  Specialized TensorFlow CNN Models
                </p>
              </div>
            </div>

            <p className="font-bengali text-xs text-sage-300 leading-relaxed mb-4">
              {t(
                'আমাদের সিস্টেমে ছবি বিশ্লেষণ সরাসরি বিশেষায়িত কম্পিউটার ভিশন মডেল কনসোলের মাধ্যমে পরিচালিত হয়। আপনি কোন ফসলের পাতা পরীক্ষা করতে চান?',
                'Image analysis in our platform is executed through dedicated CNN vision consoles. Which crop foliar sample would you like to inspect?'
              )}
            </p>

            <div className="space-y-2 mb-5">
              <button
                type="button"
                onClick={() => {
                  setShowImageGuideModal(false);
                  if (onSelectModelTool) onSelectModelTool('tomato_disease_v3');
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-forest-950 border border-forest-800 hover:border-gold-400 text-left transition-colors cursor-pointer group"
              >
                <div>
                  <p className="font-bengali font-bold text-xs text-cream-100 group-hover:text-gold-300">
                    {t('১. টমেটো পাতার রোগ নির্ণয় কনসোল', '1. Tomato Disease Vision Diagnosis')}
                  </p>
                  <p className="text-[10px] text-sage-400">
                    8 Classes • PlantVillage & PlantDoc dual split
                  </p>
                </div>
                <ArrowRight className="w-4 h-4 text-gold-400" />
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowImageGuideModal(false);
                  if (onSelectModelTool) onSelectModelTool('rice_disease');
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-forest-950 border border-forest-800 hover:border-gold-400 text-left transition-colors cursor-pointer group"
              >
                <div>
                  <p className="font-bengali font-bold text-xs text-cream-100 group-hover:text-gold-300">
                    {t('২. ধানের পাতার রোগ ও পোকা নির্ণয় কনসোল', '2. Rice Foliar Pathology Classifier')}
                  </p>
                  <p className="text-[10px] text-sage-400">
                    7 Classes • Blast, Scald, Tungro, Leaffolder, Stripes
                  </p>
                </div>
                <ArrowRight className="w-4 h-4 text-gold-400" />
              </button>
            </div>

            <div className="text-right">
              <button
                type="button"
                onClick={() => setShowImageGuideModal(false)}
                className="px-4 py-2 rounded-xl bg-forest-800 hover:bg-forest-750 text-xs font-bengali text-cream-100 transition-colors cursor-pointer"
              >
                {t('বন্ধ করুন', 'Close')}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

/** Formats message text with lightweight markdown header, bullet point, and code styling */
function renderFormattedMessage(content: string) {
  const lines = content.split('\n');
  return lines.map((line, lIdx) => {
    // Markdown H3 / H4 Headers
    if (line.startsWith('### ')) {
      return (
        <h4 key={lIdx} className="font-bold text-sm text-gold-300 mt-2 mb-1">
          {line.replace('### ', '')}
        </h4>
      );
    }
    if (line.startsWith('## ')) {
      return (
        <h3 key={lIdx} className="font-bold text-base text-gold-400 mt-2.5 mb-1.5">
          {line.replace('## ', '')}
        </h3>
      );
    }
    // Bullet list items
    if (line.trim().startsWith('• ') || line.trim().startsWith('- ')) {
      const bulletText = line.trim().replace(/^[•\-]\s*/, '');
      return (
        <div key={lIdx} className="flex items-start gap-1.5 my-1 ml-1 text-xs sm:text-sm">
          <span className="text-gold-400 font-bold">•</span>
          <div>{renderFormattedInline(bulletText)}</div>
        </div>
      );
    }
    // Numbered list items
    if (/^\d+\.\s/.test(line.trim())) {
      const match = line.trim().match(/^(\d+)\.\s*(.*)/);
      return (
        <div key={lIdx} className="flex items-start gap-1.5 my-1 ml-1 text-xs sm:text-sm">
          <span className="font-semibold text-gold-400">{match ? match[1] : '1'}.</span>
          <div>{renderFormattedInline(match ? match[2] : line)}</div>
        </div>
      );
    }
    // Empty spacer line
    if (!line.trim()) {
      return <div key={lIdx} className="h-1.5" />;
    }
    // Regular line
    return (
      <p key={lIdx} className="text-xs sm:text-sm my-0.5 leading-relaxed">
        {renderFormattedInline(line)}
      </p>
    );
  });
}

/** Parses inline markdown bold, code, and italics */
function renderFormattedInline(text: string) {
  const parts = text.split(/(\*\*.*?\*\*|\`.*?\`|\*.*?\*)/g);
  return parts.map((part, idx) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return (
        <strong key={idx} className="font-semibold text-cream-50">
          {part.slice(2, -2)}
        </strong>
      );
    }
    if (part.startsWith('`') && part.endsWith('`')) {
      return (
        <code key={idx} className="px-1 py-0.5 bg-forest-950 text-gold-300 border border-forest-800 rounded text-[11px] font-mono">
          {part.slice(1, -1)}
        </code>
      );
    }
    if (part.startsWith('*') && part.endsWith('*')) {
      return (
        <em key={idx} className="text-sage-300 italic">
          {part.slice(1, -1)}
        </em>
      );
    }
    return part;
  });
}
