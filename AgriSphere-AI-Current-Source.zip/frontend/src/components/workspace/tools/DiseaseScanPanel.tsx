import { useEffect, useRef, useState, type ChangeEvent, type DragEvent, type KeyboardEvent } from 'react';
import { AlertCircle, Camera, CheckCircle2, FlaskConical, ImagePlus, Info, Leaf, RotateCcw, ScanLine, UploadCloud, X } from 'lucide-react';
import { useLanguage } from '../../../context/LanguageContext.tsx';
import { predictionApi, getErrorMessage } from '../../../services/api.ts';
import type { PredictionResponse } from '../../../types/index.ts';
import { PredictionResultCard } from '../PredictionResultCard.tsx';
import './CropHealthLovable.css';

type CropKind = 'tomato' | 'rice';
type SampleKind = 'healthy' | 'affected';

interface DiseaseScanPanelProps {
  crop: CropKind;
  onViewHistory?: (recordId: number) => void;
}

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const ALLOWED_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);
const MODEL_IDS: Record<CropKind, string> = {
  tomato: 'tomato_disease_v3',
  rice: 'rice_disease',
};

/** Original synthetic quick-test capability, explicitly labelled as an illustration. */
function makeIllustration(crop: CropKind, sample: SampleKind): Promise<File> {
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    canvas.width = 224;
    canvas.height = 224;
    const ctx = canvas.getContext('2d');
    if (!ctx) { reject(new Error('Canvas is not available.')); return; }
    ctx.fillStyle = crop === 'tomato' ? '#2d5a3f' : '#1c3b28';
    ctx.fillRect(0, 0, 224, 224);
    ctx.fillStyle = sample === 'healthy' ? '#469c5e' : '#738a4d';
    if (crop === 'tomato') {
      ctx.beginPath();
      ctx.ellipse(112, 112, 75, 100, Math.PI / 8, 0, 2 * Math.PI);
      ctx.fill();
      ctx.strokeStyle = '#224a2e';
      ctx.lineWidth = 2;
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.moveTo(112, 10);
      ctx.quadraticCurveTo(80, 112, 95, 214);
      ctx.lineTo(129, 214);
      ctx.quadraticCurveTo(144, 112, 112, 10);
      ctx.fill();
    }
    ctx.strokeStyle = '#2d633b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(112, 20);
    ctx.lineTo(112, 204);
    ctx.stroke();
    if (sample === 'affected') {
      ctx.fillStyle = crop === 'tomato' ? '#4a2f1b' : '#8a532d';
      ctx.beginPath();
      if (crop === 'tomato') {
        ctx.arc(95, 80, 16, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(135, 130, 20, 0, Math.PI * 2);
      } else {
        ctx.ellipse(112, 95, 8, 22, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.ellipse(115, 155, 7, 18, 0.2, 0, Math.PI * 2);
      }
      ctx.fill();
    }
    canvas.toBlob(blob => {
      if (!blob) { reject(new Error('Could not create the sample image.')); return; }
      resolve(new File([blob], `${crop}_synthetic_${sample}.png`, { type: 'image/png' }));
    }, 'image/png');
  });
}

export function DiseaseScanPanel({ crop, onViewHistory }: DiseaseScanPanelProps) {
  const { lang } = useLanguage();
  const bn = lang === 'bn';
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [syntheticSample, setSyntheticSample] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<PredictionResponse | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const requestSequence = useRef(0);
  const activeRef = useRef(true);

  // Free browser preview URLs when a picture changes or the view unmounts.
  useEffect(() => {
    activeRef.current = true;
    return () => { activeRef.current = false; };
  }, []);
  useEffect(() => () => { if (previewUrl) URL.revokeObjectURL(previewUrl); }, [previewUrl]);

  const modelId = MODEL_IDS[crop];
  const cropName = crop === 'tomato' ? (bn ? 'টমেটো' : 'Tomato') : (bn ? 'ধান' : 'Rice');
  const title = bn ? 'পাতার ছবি দিয়ে রোগ শনাক্ত করুন' : 'Scan a leaf for disease';
  const subtitle = bn
    ? 'দিনের আলোতে পাতার পরিষ্কার ছবি তুলুন। ছবিতে সম্ভব হলে একটি পাতাই রাখুন।'
    : 'Take a clear photo in daylight, with one leaf filling the frame.';

  function useFile(file: File, isSynthetic = false) {
    if (!ALLOWED_TYPES.has(file.type)) {
      setError(bn ? 'শুধু JPEG, PNG অথবা WebP ছবি দিন।' : 'Choose a JPEG, PNG, or WebP image.');
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      setError(bn ? 'ছবির আকার সর্বোচ্চ ৫ MiB হতে পারবে।' : 'Maximum image size is 5 MiB.');
      return;
    }
    requestSequence.current += 1;
    setSelectedFile(file);
    setPreviewUrl(URL.createObjectURL(file));
    setResult(null);
    setError(null);
    setSyntheticSample(isSynthetic);
  }

  function onInputChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.currentTarget.files?.[0];
    if (file) useFile(file);
    event.currentTarget.value = '';
  }

  function onDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    setDragging(false);
    if (isSubmitting) return;
    const file = event.dataTransfer.files?.[0];
    if (file) useFile(file);
  }

  function onDropKey(event: KeyboardEvent<HTMLDivElement>) {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      fileInputRef.current?.click();
    }
  }

  async function onSampleClick(kind: SampleKind) {
    if (isSubmitting) return;
    try {
      useFile(await makeIllustration(crop, kind), true);
    } catch {
      setError(bn ? 'ডেমো ছবি তৈরি করা যায়নি।' : 'Could not create demo illustration.');
    }
  }

  async function handleScan() {
    if (!selectedFile || isSubmitting) return;
    const requestId = ++requestSequence.current;
    setIsSubmitting(true);
    setError(null);
    setResult(null);
    try {
      const response = await predictionApi.predictImage(modelId, selectedFile);
      if (activeRef.current && requestSequence.current === requestId) setResult(response);
    } catch (err) {
      if (activeRef.current && requestSequence.current === requestId) setError(getErrorMessage(err));
    } finally {
      if (activeRef.current) setIsSubmitting(false);
    }
  }

  function reset() {
    requestSequence.current += 1;
    setSelectedFile(null);
    setPreviewUrl(null);
    setSyntheticSample(false);
    setResult(null);
    setError(null);
    setDragging(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  }

  return (
    <section className="crop-health-ui" aria-label={bn ? 'ফসলের রোগ শনাক্তকরণ' : 'Crop disease scanner'}>
      <div className="crop-health-heading">
        <div className="crop-health-eyebrow">CROP HEALTH <span aria-hidden="true">·</span> {cropName.toUpperCase()}</div>
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>

      <div className="crop-health-columns">
        <section className="crop-health-card crop-health-upload-panel" aria-labelledby="crop-health-upload-title">
          <div className="crop-health-card-kicker" id="crop-health-upload-title">
            <Camera size={17} aria-hidden="true" /> {bn ? `${cropName} পাতার ছবি` : `${cropName} leaf photo`}
            <span className="crop-health-model-badge">{crop === 'tomato' ? '8 classes' : '7 classes'}</span>
          </div>

          <div
            className={`crop-health-dropzone ${dragging ? 'is-dragging' : ''} ${previewUrl ? 'has-image' : ''}`}
            role="button"
            tabIndex={isSubmitting ? -1 : 0}
            aria-label={bn ? 'পাতার ছবি আপলোড করুন' : 'Upload leaf photo'}
            aria-disabled={isSubmitting}
            onClick={() => { if (!isSubmitting) fileInputRef.current?.click(); }}
            onKeyDown={onDropKey}
            onDragEnter={event => { event.preventDefault(); if (!isSubmitting) setDragging(true); }}
            onDragOver={event => { event.preventDefault(); }}
            onDragLeave={event => { event.preventDefault(); setDragging(false); }}
            onDrop={onDrop}
          >
            <input
              ref={fileInputRef}
              aria-label={bn ? 'ছবি নির্বাচন' : 'Choose image'}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              onChange={onInputChange}
              className="crop-health-file-input"
              tabIndex={-1}
            />
            {previewUrl ? (
              <div className="crop-health-image-preview">
                <img src={previewUrl} alt={bn ? `${cropName} পাতার নির্বাচিত ছবি` : `Selected ${cropName} leaf`} />
                <span className="crop-health-file-name">{selectedFile?.name}</span>
                <span className="crop-health-help">{bn ? 'ছবি পরিবর্তন করতে ক্লিক করুন' : 'Click or drop another photo to replace'}</span>
              </div>
            ) : (
              <div className="crop-health-drop-prompt">
                <UploadCloud size={32} strokeWidth={1.8} aria-hidden="true" />
                <strong>{bn ? 'এখানে পাতার ছবি আনুন বা নির্বাচন করুন' : 'Drag a leaf photo here, or tap to choose'}</strong>
                <small>JPG, PNG, WebP · {bn ? 'সর্বোচ্চ ৫ MiB' : 'Up to 5 MiB'}</small>
              </div>
            )}
          </div>

          {syntheticSample && (
            <p className="crop-health-synthetic-note" role="note">
              <Info size={14} aria-hidden="true" />
              {bn ? 'এটি আঁকা ডেমো ছবি—বাস্তব ফসলের অবস্থা নয়; ফলাফল নির্ভরযোগ্য নাও হতে পারে।' : 'This is a synthetic illustration, not a real leaf. Its model result is not reliable.'}
            </p>
          )}

          <div className="crop-health-controls">
            <button
              type="button"
              className="crop-health-scan-button"
              disabled={!selectedFile || isSubmitting}
              onClick={() => { void handleScan(); }}
            >
              {isSubmitting ? <><span className="crop-health-spinner" aria-hidden="true" />{bn ? 'বিশ্লেষণ চলছে…' : 'Analyzing image…'}</> : <><ScanLine size={19} aria-hidden="true" />{bn ? 'স্ক্যান শুরু করুন' : 'Run scan'}</>}
            </button>
            {selectedFile && (
              <button type="button" className="crop-health-clear" disabled={isSubmitting} onClick={reset}>
                <X size={16} aria-hidden="true" />{bn ? 'ছবি মুছুন' : 'Clear'}
              </button>
            )}
          </div>
          <div className="crop-health-sample-row" aria-label={bn ? 'গবেষণামূলক ডেমো ছবি' : 'Synthetic research demos'}>
            <span><FlaskConical size={14} aria-hidden="true" />{bn ? 'ডেমো ইলাস্ট্রেশন:' : 'Research illustrations:'}</span>
            <button type="button" onClick={() => { void onSampleClick('healthy'); }} disabled={isSubmitting}>{bn ? 'সুস্থ পাতার নমুনা' : 'Healthy sample'}</button>
            <button type="button" onClick={() => { void onSampleClick('affected'); }} disabled={isSubmitting}>{bn ? 'আক্রান্ত পাতার নমুনা' : 'Affected sample'}</button>
          </div>
          {error && <div className="crop-health-error" role="alert"><AlertCircle size={17} aria-hidden="true" />{error}</div>}
        </section>

        <section className="crop-health-card crop-health-results-panel" aria-labelledby="crop-health-result-title" aria-live="polite">
          <div className="crop-health-card-kicker" id="crop-health-result-title">
            <Leaf size={17} aria-hidden="true" />{bn ? 'বিশ্লেষণের ফলাফল' : 'Results'}
            {result && <CheckCircle2 size={16} className="crop-health-result-ready" aria-label={bn ? 'ফলাফল এসেছে' : 'Result received'} />}
          </div>
          {result ? (
            <div className="crop-health-result-content">
              <div className="crop-health-result-intro">
                <CheckCircle2 size={18} aria-hidden="true" />
                {bn ? 'মডেল বিশ্লেষণ সম্পন্ন' : 'Model analysis complete'}
              </div>
              <div className="crop-health-result">
                <PredictionResultCard result={result} onViewHistory={onViewHistory} />
              </div>
              <p className="crop-health-disclaimer">
                <Info size={15} aria-hidden="true" />
                {bn ? 'এটি AI-ভিত্তিক প্রাথমিক অনুমান, নিশ্চিত রোগ নির্ণয় নয়। বাস্তব পাতার ছবি ব্যবহার করুন।' : 'This is a preliminary AI estimate, not a confirmed diagnosis. Use real leaf photographs.'}
              </p>
            </div>
          ) : isSubmitting ? (
            <div className="crop-health-results-empty is-loading" role="status">
              <span className="crop-health-spinner" aria-hidden="true" />
              <p>{bn ? 'ছবিটি মডেলে বিশ্লেষণ করা হচ্ছে…' : 'Analyzing the image with the selected model…'}</p>
            </div>
          ) : (
            <div className="crop-health-results-empty">
              <div className="crop-health-empty-icon"><ImagePlus size={25} strokeWidth={1.6} aria-hidden="true" /></div>
              <p>{bn ? 'ছবি আপলোড করে স্ক্যান চালালে এখানে ফলাফল দেখাবে।' : 'Upload a photo and run a scan to see the result here.'}</p>
              <span>{bn ? `${cropName} রোগ শনাক্তকরণ মডেল প্রস্তুত।` : `${cropName} disease model is ready for analysis.`}</span>
            </div>
          )}
        </section>
      </div>

      <div className="crop-health-footnote">
        <RotateCcw size={13} aria-hidden="true" />
        {bn ? 'সঠিক ফলাফলের জন্য পরিষ্কার আলোতে প্রকৃত পাতা ক্যাপচার করুন।' : 'For better input quality, capture a real leaf in clear daylight.'}
        <span className="crop-health-footnote-model">{modelId}</span>
      </div>
    </section>
  );
}
