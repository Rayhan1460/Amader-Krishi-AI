import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../../context/AuthContext.tsx';
import { useLanguage } from '../../../context/LanguageContext.tsx';
import { farmApi, farmIntelligenceApi } from '../../../services/api.ts';
import type {
  FarmProfile,
  FarmUnifiedIntelligenceResponse,
  FarmActionItem,
} from '../../../types/index.ts';
import type { WorkspaceTab } from '../WorkspaceSidebar.tsx';

import { DashboardGreeting } from './DashboardGreeting.tsx';
import { FarmWeatherAdvisoryBanner } from './FarmWeatherAdvisoryBanner.tsx';
import { TodayFarmTasksCard } from './TodayFarmTasksCard.tsx';
import { CropObservationSummaryCard } from './CropObservationSummaryCard.tsx';
import { FarmTwinPreviewCard } from './FarmTwinPreviewCard.tsx';
import { MarketResearchPreviewCard } from './MarketResearchPreviewCard.tsx';
import { AlertCircle, RefreshCw, Sprout } from 'lucide-react';

interface PremiumFarmDashboardProps {
  initialFarmId?: number | null;
  onNavigateToTab: (tab: WorkspaceTab, modelId?: string) => void;
  onSelectFarmId?: (farmId: number) => void;
}

export function PremiumFarmDashboard({
  initialFarmId = null,
  onNavigateToTab,
  onSelectFarmId,
}: PremiumFarmDashboardProps) {
  const { user } = useAuth();
  const { lang, t } = useLanguage();

  const [farms, setFarms] = useState<FarmProfile[]>([]);
  const [selectedFarmId, setSelectedFarmId] = useState<number | null>(initialFarmId);
  const [intelligence, setIntelligence] = useState<FarmUnifiedIntelligenceResponse | null>(null);
  const [actions, setActions] = useState<FarmActionItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // 1. Load authenticated farmer's farms
  useEffect(() => {
    let isMounted = true;

    async function loadFarms() {
      try {
        const loaded = await farmApi.listFarms();
        if (!isMounted) return;
        setFarms(loaded);

        if (loaded.length > 0) {
          const defaultFarm =
            (initialFarmId && loaded.find((f) => f.id === initialFarmId)) ||
            loaded.find((f) => f.is_active) ||
            loaded[0];
          setSelectedFarmId(defaultFarm.id);
          if (onSelectFarmId) onSelectFarmId(defaultFarm.id);
        } else {
          setSelectedFarmId(null);
          setLoading(false);
        }
      } catch (err: any) {
        if (!isMounted) return;
        console.error('Failed to load farms:', err);
        setError(t('খামারের তথ্য লোড করতে ব্যর্থ হয়েছে', 'Failed to load farm profiles.'));
        setLoading(false);
      }
    }

    loadFarms();

    return () => {
      isMounted = false;
    };
  }, [initialFarmId]);

  // 2. Load unified intelligence & contextual actions for the selected farm
  const loadDashboardData = useCallback(async (farmId: number) => {
    setLoading(true);
    setError(null);

    try {
      // Parallel fetch of verified intelligence & actions
      const [intelRes, actionsRes] = await Promise.allSettled([
        farmIntelligenceApi.getIntelligence(farmId),
        farmIntelligenceApi.getActions(farmId),
      ]);

      if (intelRes.status === 'fulfilled') {
        setIntelligence(intelRes.value);
      } else {
        console.warn('Failed to load farm intelligence:', intelRes.reason);
      }

      if (actionsRes.status === 'fulfilled') {
        setActions(actionsRes.value.actions || []);
      } else {
        console.warn('Failed to load farm actions:', actionsRes.reason);
        setActions([]);
      }
    } catch (err: any) {
      console.error('Dashboard load error:', err);
      setError(
        err?.response?.data?.detail ||
          t('ড্যাশবোর্ড তথ্য লোড হতে ব্যর্থ হয়েছে', 'Failed to load dashboard data.')
      );
    } finally {
      setLoading(false);
    }
  }, [t]);

  // Trigger data load on farm selection change
  useEffect(() => {
    if (selectedFarmId) {
      loadDashboardData(selectedFarmId);
    }
  }, [selectedFarmId, loadDashboardData]);

  // Farm selection handler
  const handleSelectFarm = (farmId: number) => {
    setSelectedFarmId(farmId);
    if (onSelectFarmId) onSelectFarmId(farmId);
  };

  const selectedFarmProfile =
    farms.find((f) => f.id === selectedFarmId) || intelligence?.farm || null;

  return (
    <div className="w-full min-h-[calc(100vh-4rem)] bg-[#001c12] text-cream-50 p-4 sm:p-6 lg:p-8 animate-fade-in-up">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* 1. Dashboard Greeting with Real Authenticated Farm Context */}
        <DashboardGreeting
          user={user}
          selectedFarm={selectedFarmProfile}
          farms={farms}
          onSelectFarm={handleSelectFarm}
          isLoading={loading && !intelligence}
        />

        {/* Error State with Retry Button */}
        {error && (
          <div className="p-4 rounded-xl bg-red-950/60 border border-red-800/80 text-red-200 flex items-center justify-between gap-3 text-xs sm:text-sm">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{error}</span>
            </div>
            {selectedFarmId && (
              <button
                onClick={() => loadDashboardData(selectedFarmId)}
                className="px-3 py-1 rounded-lg bg-red-900/80 hover:bg-red-800 text-white font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>{t('পুনরায় চেষ্টা করুন', 'Retry')}</span>
              </button>
            )}
          </div>
        )}

        {/* Empty State when farmer has no registered farms */}
        {!loading && farms.length === 0 && (
          <div className="p-8 text-center bg-[#082b1f] border border-[#1b4332] rounded-2xl flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-[#062519] flex items-center justify-center text-[#e9ad46] mb-3">
              <Sprout className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white mb-1">
              {lang === 'bn' ? 'কোনো নিবন্ধিত খামার পাওয়া যায়নি' : 'No Farms Registered Yet'}
            </h3>
            <p className="text-xs sm:text-sm text-[#a7b9ae] max-w-md mb-4">
              {lang === 'bn'
                ? 'আপনার খামারের অবস্থান, মাটির ধরন ও আকার যোগ করে পূর্ণাঙ্গ ড্যাশবোর্ড সুবিধা গ্রহণ করুন।'
                : 'Create your first farm profile to activate the smart decision dashboard and digital twin.'}
            </p>
            <button
              onClick={() => onNavigateToTab('calendar')}
              className="px-4 py-2 rounded-xl bg-[#153f2e] hover:bg-[#1e5841] text-xs sm:text-sm font-semibold text-[#e9ad46] border border-[#e9ad46]/30 transition-all cursor-pointer"
            >
              {lang === 'bn' ? '+ খামার প্রোফাইল তৈরি করুন' : '+ Create Farm Profile'}
            </button>
          </div>
        )}

        {/* 2. Advisory Banner: Actionable Review Items from Rules / Weather */}
        {selectedFarmId && (
          <FarmWeatherAdvisoryBanner
            actions={actions}
            weatherSummary={intelligence?.weather_summary}
            onNavigateToTab={onNavigateToTab}
            isLoading={loading && !intelligence}
          />
        )}

        {/* 3. Main Dashboard Grid matching 02_dashboard_reference.png */}
        {selectedFarmId && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

            {/* Left Column (~60-65% width): Today's Tasks + Farm Digital Twin */}
            <div className="lg:col-span-7 space-y-6 flex flex-col justify-between">
              
              {/* Card 1: Today's Farm Tasks */}
              <TodayFarmTasksCard
                tasks={intelligence?.tasks_summary?.due_today_tasks ? intelligence.tasks_summary.upcoming_tasks : intelligence?.tasks_summary?.upcoming_tasks}
                overdueTasks={intelligence?.tasks_summary?.overdue_tasks_list}
                allTasks={intelligence?.tasks_summary?.all_tasks}
                onNavigateToTab={onNavigateToTab}
                isLoading={loading && !intelligence}
              />

              {/* Card 2: Farm Digital Twin (Schematic Plot Layout) */}
              <FarmTwinPreviewCard
                farm={intelligence?.farm}
                crops={intelligence?.crops_summary?.crops}
                onNavigateToTab={onNavigateToTab}
                isLoading={loading && !intelligence}
              />

            </div>

            {/* Right Column (~35-40% width): Crop Observation + Market Intelligence */}
            <div className="lg:col-span-5 space-y-6 flex flex-col justify-between">
              
              {/* Card 3: Crop Monitoring & Observation Summary */}
              <CropObservationSummaryCard
                totalCrops={intelligence?.crops_summary?.total_crops}
                activeCropsCount={intelligence?.crops_summary?.active_crops_count}
                observationsSummary={intelligence?.observations_summary}
                onNavigateToTab={onNavigateToTab}
                isLoading={loading && !intelligence}
              />

              {/* Card 4: Market Intelligence Preview */}
              <MarketResearchPreviewCard
                onNavigateToTab={onNavigateToTab}
                isLoading={loading && !intelligence}
              />

            </div>

          </div>
        )}

      </div>
    </div>
  );
}

