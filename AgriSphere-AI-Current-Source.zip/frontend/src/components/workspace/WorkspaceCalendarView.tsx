import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Calendar as CalendarIcon,
  Clock,
  Plus,
  CheckCircle2,
  Circle,
  AlertCircle,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Trash2,
  CalendarClock,
  MapPin,
  Sprout,
  Layers,
  Droplets,
  Sparkles,
  X,
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  ArrowRight,
  BookOpen,
  CloudSun,
  CloudRain,
  Eye,
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { farmApi, calendarApi, weatherApi, getErrorMessage } from '../../services/api.ts';
import { GrowthTimeline } from '../calendar/GrowthTimeline.tsx';
import { SchedulePreviewPanel } from '../calendar/SchedulePreviewPanel.tsx';
import { WeatherDashboardPanel } from '../weather/WeatherDashboardPanel.tsx';
import { WeatherAdvisoryBanner } from '../weather/WeatherAdvisoryBanner.tsx';
import { NotificationBell } from '../reminders/NotificationBell.tsx';
import type {
  FarmProfile,
  FarmCreatePayload,
  FarmCrop,
  CropCreatePayload,
  CalendarTask,
  TaskCreatePayload,
  CalendarSummary,
  BDDivisionsMap,
  CropScheduleTemplate,
  ScheduleGenerateResult,
  GeneratedTaskItem,
  CalendarWeatherAdvisory,
} from '../../types/index.ts';
import type { WorkspaceTab } from './WorkspaceSidebar.tsx';

interface WorkspaceCalendarViewProps {
  onBackToDashboard?: () => void;
  onNavigateToModel?: (modelId: string) => void;
  onNavigateToTab?: (tab: WorkspaceTab, modelIdOrFarmId?: string, extraId?: number) => void;
}

// Fallback Administrative Divisions & Districts of Bangladesh
const FALLBACK_DIVISIONS: BDDivisionsMap = {
  Dhaka: ['Dhaka', 'Gazipur', 'Narayanganj', 'Tangail', 'Faridpur', 'Manikganj', 'Munshiganj', 'Narsingdi', 'Kishoreganj', 'Gopalganj', 'Madaripur', 'Rajbari', 'Shariatpur'],
  Chattogram: ['Chattogram', "Cox's Bazar", 'Cumilla', 'Feni', 'Brahmanbaria', 'Noakhali', 'Chandpur', 'Lakshmipur', 'Khagrachhari', 'Rangamati', 'Bandarban'],
  Rajshahi: ['Rajshahi', 'Bogura', 'Pabna', 'Sirajganj', 'Naogaon', 'Natore', 'Chapai Nawabganj', 'Joypurhat'],
  Khulna: ['Khulna', 'Jashore', 'Kushtia', 'Satkhira', 'Bagerhat', 'Jhenaidah', 'Chuadanga', 'Magura', 'Meherpur', 'Narail'],
  Barishal: ['Barishal', 'Patuakhali', 'Bhola', 'Pirojpur', 'Barguna', 'Jhalokati'],
  Sylhet: ['Sylhet', 'Moulvibazar', 'Habiganj', 'Sunamganj'],
  Rangpur: ['Rangpur', 'Dinajpur', 'Kurigram', 'Gaibandha', 'Nilphamari', 'Lalmonirhat', 'Thakurgaon', 'Panchagarh'],
  Mymensingh: ['Mymensingh', 'Jamalpur', 'Netrokona', 'Sherpur'],
};

// Category details with Bangla and English translations
const TASK_CATEGORIES: { id: string; labelBn: string; labelEn: string; icon: any; color: string }[] = [
  { id: 'land_preparation', labelBn: 'জমি প্রস্তুতি ও চাষ', labelEn: 'Land Preparation', icon: Sprout, color: 'text-amber-400 bg-amber-400/10 border-amber-400/30' },
  { id: 'sowing', labelBn: 'বীজ বপন', labelEn: 'Sowing', icon: Sprout, color: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/30' },
  { id: 'transplanting', labelBn: 'চারা রোপণ', labelEn: 'Transplanting', icon: Sprout, color: 'text-green-400 bg-green-400/10 border-green-400/30' },
  { id: 'irrigation', labelBn: 'সেচ ও পানি নিষ্কাশন', labelEn: 'Irrigation & Drainage', icon: Droplets, color: 'text-sky-400 bg-sky-400/10 border-sky-400/30' },
  { id: 'nutrient_management', labelBn: 'সুষম সার ও পুষ্টি', labelEn: 'Nutrient & Fertilizer', icon: Layers, color: 'text-purple-400 bg-purple-400/10 border-purple-400/30' },
  { id: 'crop_observation', labelBn: 'ফসল পরিদর্শন ও আগাছা দমন', labelEn: 'Scouting & Weeding', icon: ShieldCheck, color: 'text-teal-400 bg-teal-400/10 border-teal-400/30' },
  { id: 'harvest_planning', labelBn: 'ফসল কর্তন ও সংগ্রহ', labelEn: 'Harvest Planning', icon: Sparkles, color: 'text-gold-400 bg-gold-400/10 border-gold-400/30' },
  { id: 'general', labelBn: 'সাধারণ খামার কাজ', labelEn: 'General Farm Task', icon: CalendarIcon, color: 'text-sage-300 bg-sage-400/10 border-sage-400/30' },
];

const BENGALI_MONTHS = [
  'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
  'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
];

const BENGALI_WEEKDAYS = ['শনি', 'রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র'];
const ENGLISH_WEEKDAYS = ['Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri'];

// Format date helper (YYYY-MM-DD)
function formatDateStr(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Convert English digits to Bengali digits
function toBnDigits(num: number | string): string {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(num).replace(/\d/g, (d) => bnDigits[parseInt(d, 10)]);
}

export function WorkspaceCalendarView({ onBackToDashboard, onNavigateToModel, onNavigateToTab }: WorkspaceCalendarViewProps) {
  const { t, lang } = useLanguage();

  // Core Data State
  const [farms, setFarms] = useState<FarmProfile[]>([]);
  const [crops, setCrops] = useState<FarmCrop[]>([]);
  const [tasks, setTasks] = useState<CalendarTask[]>([]);
  const [summary, setSummary] = useState<CalendarSummary | null>(null);
  const [divisions, setDivisions] = useState<BDDivisionsMap>(FALLBACK_DIVISIONS);
  const [templates, setTemplates] = useState<CropScheduleTemplate[]>([]);

  // UI & Filter State
  const [viewMode, setViewMode] = useState<'month' | 'week' | 'agenda'>('month');
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedFarmId, setSelectedFarmId] = useState<number | 'all'>('all');
  const [selectedCropId, setSelectedCropId] = useState<number | 'all'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string | 'all'>('all');
  const [selectedStatus, setSelectedStatus] = useState<string | 'all'>('all');

  // Loading & Feedback State
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isActionPending, setIsActionPending] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Modals State
  const [isAddFarmOpen, setIsAddFarmOpen] = useState<boolean>(false);
  const [isAddCropOpen, setIsAddCropOpen] = useState<boolean>(false);
  const [isAddTaskOpen, setIsAddTaskOpen] = useState<boolean>(false);
  const [isRescheduleOpen, setIsRescheduleOpen] = useState<boolean>(false);
  const [selectedTask, setSelectedTask] = useState<CalendarTask | null>(null);

  // Phase F4B & F4C: Smart Schedule, Timeline & Weather State
  const [mainTab, setMainTab] = useState<'calendar' | 'timeline' | 'weather' | 'provenance'>('calendar');
  const [isScheduleGenModalOpen, setIsScheduleGenModalOpen] = useState<boolean>(false);
  const [isSchedulePreviewOpen, setIsSchedulePreviewOpen] = useState<boolean>(false);
  const [schedulePreview, setSchedulePreview] = useState<ScheduleGenerateResult | null>(null);
  const [isGeneratingSchedule, setIsGeneratingSchedule] = useState<boolean>(false);
  const [isConfirmingSchedule, setIsConfirmingSchedule] = useState<boolean>(false);
  const [selectedTimelineTemplate, setSelectedTimelineTemplate] = useState<CropScheduleTemplate | null>(null);

  // Phase F4C: Weather Intelligence & Smart Advisories State
  const [weatherAdvisories, setWeatherAdvisories] = useState<CalendarWeatherAdvisory[]>([]);
  const [selectedWeatherAdvisory, setSelectedWeatherAdvisory] = useState<CalendarWeatherAdvisory | null>(null);
  const [isWeatherRescheduleOpen, setIsWeatherRescheduleOpen] = useState<boolean>(false);
  const [weatherRescheduleDate, setWeatherRescheduleDate] = useState<string>('');
  const [isReschedulingWeather, setIsReschedulingWeather] = useState<boolean>(false);

  // Generator Form State
  const [genForm, setGenForm] = useState<{
    farm_id: number;
    crop_id: number;
    planting_date: string;
    variety: string;
    season: string;
  }>({
    farm_id: 0,
    crop_id: 0,
    planting_date: formatDateStr(new Date()),
    variety: '',
    season: '',
  });

  // Farm Form State
  const [farmForm, setFarmForm] = useState<FarmCreatePayload>({
    name: '',
    division: 'Dhaka',
    district: 'Dhaka',
    upazila: '',
    village: '',
    area: 33,
    area_unit: 'Decimal',
    soil_type: 'Loam',
    notes: '',
  });

  // Crop Form State
  const [cropForm, setCropForm] = useState<CropCreatePayload & { farm_id: number }>({
    farm_id: 0,
    crop_name: 'Rice',
    variety: 'BRRI Dhan-28',
    season: 'Rabi',
    sowing_date: formatDateStr(new Date()),
    transplanting_date: '',
    expected_harvest_date: '',
    status: 'planted',
    notes: '',
  });

  // Task Form State
  const [taskForm, setTaskForm] = useState<TaskCreatePayload>({
    farm_id: 0,
    crop_id: null,
    title: '',
    category: 'irrigation',
    due_date: formatDateStr(new Date()),
    due_time: '08:00',
    priority: 'medium',
    notes: '',
  });

  // Reschedule Form State
  const [rescheduleDate, setRescheduleDate] = useState<string>(formatDateStr(new Date()));
  const [rescheduleTime, setRescheduleTime] = useState<string>('08:00');
  const [rescheduleNotes, setRescheduleNotes] = useState<string>('');

  // Initial load
  const loadAllData = useCallback(async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const [farmsData, cropsData, tasksData, summaryData, divisionsData, templatesData] = await Promise.all([
        farmApi.listFarms(),
        farmApi.listAllCrops(),
        calendarApi.listTasks(),
        calendarApi.getSummary(),
        calendarApi.getDivisions().catch(() => FALLBACK_DIVISIONS),
        calendarApi.getTemplates().catch(() => []),
      ]);

      setFarms(farmsData);
      setCrops(cropsData);
      setTasks(tasksData);
      setSummary(summaryData);
      if (divisionsData && Object.keys(divisionsData).length > 0) {
        setDivisions(divisionsData);
      }
      setTemplates(templatesData);

      // Pre-select first farm if farmForm has no valid farm_id
      if (farmsData.length > 0) {
        setCropForm((prev) => ({ ...prev, farm_id: farmsData[0].id }));
        setTaskForm((prev) => ({ ...prev, farm_id: farmsData[0].id }));
        // Phase F4C: Load weather advisories for primary farm
        weatherApi.getAdvisories(farmsData[0].id)
          .then((advRes) => setWeatherAdvisories(advRes.advisories || []))
          .catch((err) => console.warn('Weather advisories load:', err));
      }
    } catch (err) {
      setErrorMessage(getErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // Flash auto-dismiss for messages
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  // Filtered crops based on selected farm in forms or global filter
  const cropsForSelectedFarm = useMemo(() => {
    if (taskForm.farm_id) {
      return crops.filter((c) => c.farm_id === taskForm.farm_id);
    }
    return crops;
  }, [crops, taskForm.farm_id]);

  // Filtered tasks based on active filters
  const filteredTasks = useMemo(() => {
    return tasks.filter((task) => {
      if (selectedFarmId !== 'all' && task.farm_id !== selectedFarmId) return false;
      if (selectedCropId !== 'all' && task.crop_id !== selectedCropId) return false;
      if (selectedCategory !== 'all' && task.category !== selectedCategory) return false;
      if (selectedStatus !== 'all') {
        if (selectedStatus === 'overdue' && !task.is_overdue) return false;
        if (selectedStatus !== 'overdue' && task.status !== selectedStatus) return false;
      }
      return true;
    });
  }, [tasks, selectedFarmId, selectedCropId, selectedCategory, selectedStatus]);

  // Calendar month dates calculation
  const calendarGridDays = useMemo(() => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);

    // Saturday is day 0 in our Sat->Fri grid
    // Standard getDay(): Sun=0, Mon=1, ..., Sat=6
    // In Sat=0 system: Sat=0, Sun=1, Mon=2, Tue=3, Wed=4, Thu=5, Fri=6
    const standardDay = firstDayOfMonth.getDay();
    const startOffset = (standardDay + 1) % 7;

    const days: { dateStr: string; dayNum: number; isCurrentMonth: boolean; isToday: boolean; dateObj: Date }[] = [];

    // Today in YYYY-MM-DD
    const todayStr = summary?.current_dhaka_date || formatDateStr(new Date());

    // Previous month padding
    const prevMonthLastDate = new Date(year, month, 0).getDate();
    for (let i = startOffset - 1; i >= 0; i--) {
      const dayNum = prevMonthLastDate - i;
      const d = new Date(year, month - 1, dayNum);
      const dateStr = formatDateStr(d);
      days.push({
        dateStr,
        dayNum,
        isCurrentMonth: false,
        isToday: dateStr === todayStr,
        dateObj: d,
      });
    }

    // Current month days
    for (let i = 1; i <= lastDayOfMonth.getDate(); i++) {
      const d = new Date(year, month, i);
      const dateStr = formatDateStr(d);
      days.push({
        dateStr,
        dayNum: i,
        isCurrentMonth: true,
        isToday: dateStr === todayStr,
        dateObj: d,
      });
    }

    // Next month padding to fill complete weeks (up to multiple of 7)
    const totalCells = Math.ceil(days.length / 7) * 7;
    const remaining = totalCells - days.length;
    for (let i = 1; i <= remaining; i++) {
      const d = new Date(year, month + 1, i);
      const dateStr = formatDateStr(d);
      days.push({
        dateStr,
        dayNum: i,
        isCurrentMonth: false,
        isToday: dateStr === todayStr,
        dateObj: d,
      });
    }

    return days;
  }, [currentDate, summary]);

  // Month navigation handlers
  const handlePrevMonth = () => {
    setCurrentDate((prev) => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate((prev) => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
  };

  const handleToday = () => {
    setCurrentDate(new Date());
  };

  // Form Handlers
  const handleCreateFarm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!farmForm.name.trim()) return;

    setIsActionPending(true);
    setErrorMessage(null);
    try {
      const newFarm = await farmApi.createFarm(farmForm);
      setSuccessMessage(t(`খামার "${newFarm.name}" সফলভাবে যুক্ত হয়েছে!`, `Farm "${newFarm.name}" created successfully!`));
      setIsAddFarmOpen(false);
      setFarmForm({
        name: '',
        division: 'Dhaka',
        district: 'Dhaka',
        upazila: '',
        village: '',
        area: 33,
        area_unit: 'Decimal',
        soil_type: 'Loam',
        notes: '',
      });
      await loadAllData();
    } catch (err) {
      setErrorMessage(getErrorMessage(err));
    } finally {
      setIsActionPending(false);
    }
  };

  const handleCreateCrop = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cropForm.farm_id || !cropForm.crop_name.trim()) return;

    setIsActionPending(true);
    setErrorMessage(null);
    try {
      const newCrop = await farmApi.addCrop(cropForm.farm_id, {
        crop_name: cropForm.crop_name,
        variety: cropForm.variety || undefined,
        season: cropForm.season,
        sowing_date: cropForm.sowing_date,
        transplanting_date: cropForm.transplanting_date || undefined,
        expected_harvest_date: cropForm.expected_harvest_date || undefined,
        status: cropForm.status,
        notes: cropForm.notes || undefined,
      });
      setSuccessMessage(t(`ফসল "${newCrop.crop_name}" খামারে সফলভাবে যুক্ত হয়েছে!`, `Crop "${newCrop.crop_name}" added successfully!`));
      setIsAddCropOpen(false);
      await loadAllData();
    } catch (err) {
      setErrorMessage(getErrorMessage(err));
    } finally {
      setIsActionPending(false);
    }
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskForm.farm_id || !taskForm.title.trim() || !taskForm.due_date) return;

    setIsActionPending(true);
    setErrorMessage(null);
    try {
      const newTask = await calendarApi.createTask({
        farm_id: taskForm.farm_id,
        crop_id: taskForm.crop_id ? Number(taskForm.crop_id) : null,
        title: taskForm.title.trim(),
        category: taskForm.category,
        due_date: taskForm.due_date,
        due_time: taskForm.due_time || undefined,
        priority: taskForm.priority,
        notes: taskForm.notes || undefined,
      });
      setSuccessMessage(t(`কাজ "${newTask.title}" ক্যালেন্ডারে যুক্ত হয়েছে!`, `Task "${newTask.title}" added to calendar!`));
      setIsAddTaskOpen(false);
      setTaskForm((prev) => ({
        ...prev,
        title: '',
        notes: '',
      }));
      await loadAllData();
    } catch (err) {
      setErrorMessage(getErrorMessage(err));
    } finally {
      setIsActionPending(false);
    }
  };

  const handleToggleTaskStatus = async (task: CalendarTask) => {
    const nextStatus = task.status === 'completed' ? 'pending' : 'completed';
    try {
      await calendarApi.patchTaskStatus(task.id, nextStatus);
      setSuccessMessage(
        nextStatus === 'completed'
          ? t(`"${task.title}" সম্পন্ন হিসেবে চিহ্নিত করা হলো`, `"${task.title}" marked as completed`)
          : t(`"${task.title}" কাজ পুনরায় সক্রিয় করা হলো`, `"${task.title}" reopened`)
      );
      await loadAllData();
    } catch (err) {
      setErrorMessage(getErrorMessage(err));
    }
  };

  const handleRescheduleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask || !rescheduleDate) return;

    setIsActionPending(true);
    setErrorMessage(null);
    try {
      await calendarApi.rescheduleTask(selectedTask.id, {
        due_date: rescheduleDate,
        due_time: rescheduleTime || undefined,
        notes: rescheduleNotes ? rescheduleNotes.trim() : undefined,
      });
      setSuccessMessage(t(`কাজটির সময়সূচি সফলভাবে পরিবর্তন করা হয়েছে!`, `Task rescheduled successfully!`));
      setIsRescheduleOpen(false);
      setSelectedTask(null);
      await loadAllData();
    } catch (err) {
      setErrorMessage(getErrorMessage(err));
    } finally {
      setIsActionPending(false);
    }
  };

  const handleDeleteTask = async (taskId: number) => {
    if (!window.confirm(t('আপনি কি নিশ্চিত যে এই কাজটি মুছে ফেলতে চান?', 'Are you sure you want to delete this task?'))) {
      return;
    }

    try {
      await calendarApi.deleteTask(taskId);
      setSuccessMessage(t('কাজটি সফলভাবে মুছে ফেলা হয়েছে', 'Task deleted successfully'));
      if (selectedTask?.id === taskId) {
        setSelectedTask(null);
        setIsRescheduleOpen(false);
      }
      await loadAllData();
    } catch (err) {
      setErrorMessage(getErrorMessage(err));
    }
  };

  const openRescheduleModal = (task: CalendarTask) => {
    setSelectedTask(task);
    setRescheduleDate(task.due_date);
    setRescheduleTime(task.due_time || '08:00');
    setRescheduleNotes(task.notes || '');
    setIsRescheduleOpen(true);
  };

  const openAddTaskForDate = (dateStr: string) => {
    setTaskForm((prev) => ({
      ...prev,
      due_date: dateStr,
      farm_id: farms.length > 0 ? (selectedFarmId !== 'all' ? selectedFarmId : farms[0].id) : 0,
    }));
    setIsAddTaskOpen(true);
  };

  // =========================================================================
  // PHASE F4B: SCHEDULE GENERATOR & CONFIRMATION HANDLERS
  // =========================================================================
  const handleOpenScheduleGenerator = (initialFarmId?: number, initialCropId?: number) => {
    const fId = initialFarmId || (selectedFarmId !== 'all' ? selectedFarmId : (farms[0]?.id || 0));
    const farmCrops = crops.filter((c) => c.farm_id === fId);
    const cId = initialCropId || (selectedCropId !== 'all' ? selectedCropId : (farmCrops[0]?.id || crops[0]?.id || 0));
    const matchedCrop = crops.find((c) => c.id === cId);

    setGenForm({
      farm_id: fId,
      crop_id: cId,
      planting_date: matchedCrop?.sowing_date || formatDateStr(new Date()),
      variety: matchedCrop?.variety || '',
      season: matchedCrop?.season || 'Rabi',
    });
    setIsScheduleGenModalOpen(true);
  };

  const handleRunScheduleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!genForm.farm_id || !genForm.crop_id || !genForm.planting_date) return;

    setIsGeneratingSchedule(true);
    setErrorMessage(null);
    try {
      const res = await calendarApi.generateSchedule({
        farm_id: genForm.farm_id,
        crop_id: genForm.crop_id,
        planting_date: genForm.planting_date,
        target_variety: genForm.variety || undefined,
        season: genForm.season || undefined,
      });
      setSchedulePreview(res);
      setIsScheduleGenModalOpen(false);
      setIsSchedulePreviewOpen(true);
    } catch (err) {
      setErrorMessage(getErrorMessage(err));
    } finally {
      setIsGeneratingSchedule(false);
    }
  };

  const handleConfirmSchedule = async (tasksToConfirm: GeneratedTaskItem[]) => {
    if (!schedulePreview) return;

    setIsConfirmingSchedule(true);
    setErrorMessage(null);
    try {
      const res = await calendarApi.confirmSchedule({
        farm_id: schedulePreview.farm_id,
        crop_id: schedulePreview.crop_id,
        template_id: schedulePreview.template_id || 'custom',
        planting_date: schedulePreview.planting_date,
        schedule_hash: schedulePreview.schedule_hash,
        tasks: tasksToConfirm,
      });

      setSuccessMessage(
        lang === 'bn'
          ? (res.message_bn || 'স্মার্ট কৃষি পরিকল্পনা সফলভাবে ক্যালেন্ডারে সংরক্ষিত হয়েছে!')
          : (res.message || 'Smart schedule confirmed and saved to calendar!')
      );
      setIsSchedulePreviewOpen(false);
      setSchedulePreview(null);
      await loadAllData();
    } catch (err) {
      setErrorMessage(getErrorMessage(err));
    } finally {
      setIsConfirmingSchedule(false);
    }
  };

  // Helper for category badge
  const getCategoryMeta = (catId: string) => {
    return TASK_CATEGORIES.find((c) => c.id === catId) || TASK_CATEGORIES[TASK_CATEGORIES.length - 1];
  };

  // Helper for priority badge
  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return (
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
            {t('অতি জরুরি', 'Urgent')}
          </span>
        );
      case 'high':
        return (
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
            {t('উচ্চ', 'High')}
          </span>
        );
      case 'medium':
        return (
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            {t('সাধারণ', 'Normal')}
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded-md text-[10px] font-medium bg-forest-800 text-sage-300 border border-forest-700">
            {t('নিম্ন', 'Low')}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-fade-in-up pb-12">
      {/* Toast Feedback */}
      {errorMessage && (
        <div className="p-4 rounded-2xl bg-rose-950/80 border border-rose-600/60 text-rose-200 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            <span className="text-xs sm:text-sm font-bengali">{errorMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setErrorMessage(null)}
            className="p-1 rounded-lg hover:bg-rose-900/50 text-rose-300 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {successMessage && (
        <div className="p-4 rounded-2xl bg-emerald-950/80 border border-emerald-600/60 text-emerald-200 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="text-xs sm:text-sm font-bengali font-semibold">{successMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setSuccessMessage(null)}
            className="p-1 rounded-lg hover:bg-emerald-900/50 text-emerald-300 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Banner & Control Deck */}
      <div className="rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-forest-950 via-forest-900 to-[#071810] border border-gold-500/40 text-cream-50 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gold-400/10 blur-3xl rounded-full pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold-400/20 border border-gold-400/30 text-gold-300 text-xs font-mono font-bold mb-3">
              <Sparkles className="w-3.5 h-3.5 text-gold-400" />
              <span>{t('স্মার্ট কৃষি ক্যালেন্ডার ও খামার প্রোফাইল • ফেজ F4A', 'Smart Agricultural Calendar & Farm Profiles • Phase F4A')}</span>
            </div>

            <h1 className="font-bengali font-black text-2xl sm:text-4xl text-cream-50 mb-2">
              {t('স্মার্ট কৃষি ক্যালেন্ডার', 'Smart Agricultural Calendar')}
            </h1>

            <p className="font-bengali text-xs sm:text-sm text-sage-200 leading-relaxed mb-4">
              {t(
                'বাংলাদেশের বাস্তব কৃষিকাজের সময়সূচি, খামার ব্যবস্থাপনা, ফসল চক্র এবং প্রতিদিনের কৃষি কাজের ডেটাবেজ-সংযুক্ত কার্যকরী ক্যালেন্ডার।',
                'Real, database-backed agricultural scheduling, farm profiles, crop lifecycles, and day-to-day farming tasks for Bangladesh.'
              )}
            </p>

            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-forest-900/90 border border-forest-750 text-xs text-gold-300 font-mono">
              <CalendarClock className="w-4 h-4 text-gold-400" />
              <span>
                {t('আজকের তারিখ (ঢাকা সময়):', 'Today (Asia/Dhaka):')}{' '}
                <strong className="text-cream-100">
                  {summary?.current_dhaka_date
                    ? lang === 'bn'
                      ? toBnDigits(summary.current_dhaka_date)
                      : summary.current_dhaka_date
                    : formatDateStr(new Date())}
                </strong>
              </span>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
            {/* Phase F4B: AI Smart Schedule Generator CTA */}
            <button
              type="button"
              onClick={() => handleOpenScheduleGenerator()}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-gold-500 via-gold-400 to-amber-500 hover:from-gold-400 hover:to-gold-300 text-forest-950 text-xs font-bengali font-bold border border-gold-300 transition-all cursor-pointer shadow-xl hover:scale-[1.03]"
            >
              <Sparkles className="w-4 h-4 text-forest-950 animate-pulse" />
              <span>{t('✨ স্মার্ট পরিকল্পনা তৈরি', '✨ AI Schedule Generator')}</span>
            </button>

            {onNavigateToTab && (
              <button
                type="button"
                data-testid="calendar-goto-monitoring-btn"
                onClick={() => onNavigateToTab('crop_monitoring', selectedFarmId !== 'all' ? String(selectedFarmId) : undefined)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-forest-800/90 hover:bg-forest-750 text-teal-300 text-xs font-bengali font-semibold border border-teal-500/40 transition-all cursor-pointer shadow-md hover:scale-[1.02]"
              >
                <Eye className="w-4 h-4 text-teal-400" />
                <span>{t('ফসল পর্যবেক্ষণ', 'Crop Monitoring')}</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setIsAddFarmOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-forest-800 to-forest-750 hover:from-forest-750 hover:to-forest-700 text-cream-50 text-xs font-bengali font-semibold border border-forest-600 transition-all cursor-pointer shadow-md hover:scale-[1.02]"
            >
              <Sprout className="w-4 h-4 text-gold-400" />
              <span>{t('+ নতুন খামার যোগ', '+ Add Farm')}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (farms.length === 0) {
                  setIsAddFarmOpen(true);
                } else {
                  setIsAddCropOpen(true);
                }
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-forest-800 to-forest-750 hover:from-forest-750 hover:to-forest-700 text-cream-50 text-xs font-bengali font-semibold border border-forest-600 transition-all cursor-pointer shadow-md hover:scale-[1.02]"
            >
              <Layers className="w-4 h-4 text-emerald-400" />
              <span>{t('+ ফসল নির্ধারণ', '+ Add Crop')}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (farms.length === 0) {
                  setIsAddFarmOpen(true);
                } else {
                  setIsAddTaskOpen(true);
                }
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-400 hover:to-gold-500 text-forest-950 text-xs font-bengali font-bold border border-gold-400 transition-all cursor-pointer shadow-lg hover:scale-[1.02]"
            >
              <Plus className="w-4 h-4 text-forest-950" />
              <span>{t('+ নতুন কাজ যোগ করুন', '+ Add New Task')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Phase F4B Main View Tabs Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-2 rounded-2xl bg-forest-950/80 border border-forest-800">
        <div className="flex flex-wrap items-center gap-1 sm:gap-2">
          <button
            type="button"
            onClick={() => setMainTab('calendar')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bengali font-semibold transition-all cursor-pointer ${
              mainTab === 'calendar'
                ? 'bg-gold-500 text-forest-950 shadow-md font-bold'
                : 'text-sage-300 hover:bg-forest-900 hover:text-cream-100'
            }`}
          >
            <CalendarIcon className="w-3.5 h-3.5" />
            <span>{t('কৃষি ক্যালেন্ডার ও কাজ', 'Calendar & Tasks')}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setMainTab('timeline');
              if (!selectedTimelineTemplate && templates.length > 0) {
                setSelectedTimelineTemplate(templates[0]);
              }
            }}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bengali font-semibold transition-all cursor-pointer ${
              mainTab === 'timeline'
                ? 'bg-gold-500 text-forest-950 shadow-md font-bold'
                : 'text-sage-300 hover:bg-forest-900 hover:text-cream-100'
            }`}
          >
            <Sprout className="w-3.5 h-3.5" />
            <span>{t('বৈজ্ঞানিক বৃদ্ধি পরিক্রমা', 'Growth Lifecycle Timeline')}</span>
          </button>

          <button
            type="button"
            onClick={() => setMainTab('weather')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bengali font-semibold transition-all cursor-pointer ${
              mainTab === 'weather'
                ? 'bg-gold-500 text-forest-950 shadow-md font-bold'
                : 'text-sage-300 hover:bg-forest-900 hover:text-cream-100'
            }`}
          >
            <CloudSun className="w-3.5 h-3.5" />
            <span>{t('আবহাওয়া ও পূর্বাভাস', 'Weather & Intelligence')}</span>
          </button>

          <button
            type="button"
            onClick={() => setMainTab('provenance')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bengali font-semibold transition-all cursor-pointer ${
              mainTab === 'provenance'
                ? 'bg-gold-500 text-forest-950 shadow-md font-bold'
                : 'text-sage-300 hover:bg-forest-900 hover:text-cream-100'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>{t('গবেষণা উৎস ও তথ্যপ্রমাণ', 'Research Provenance & Standards')}</span>
          </button>
        </div>

        {/* Quick Action in Tab Bar: Notification Bell & Generator */}
        <div className="flex items-center gap-2">
          <NotificationBell
            onOpenReschedule={(taskId) => {
              const tItem = tasks.find((tk) => tk.id === taskId);
              if (tItem) {
                setSelectedTask(tItem);
                setRescheduleDate(tItem.due_date);
                setIsRescheduleOpen(true);
              }
            }}
            onSelectTask={(taskId) => {
              const tItem = tasks.find((tk) => tk.id === taskId);
              if (tItem) {
                setSelectedTask(tItem);
              }
            }}
          />
          <button
            type="button"
            onClick={() => handleOpenScheduleGenerator()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-forest-900 hover:bg-forest-850 text-gold-300 text-xs font-bengali border border-forest-750 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3 h-3 text-gold-400" />
            <span>{t('পরিকল্পনা জেনারেটর', 'Schedule Generator')}</span>
          </button>
        </div>
      </div>

      {/* Summary Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Total Farms */}
        <div className="rounded-2xl p-4 bg-forest-900/80 border border-forest-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-sage-400 font-bengali">{t('মোট খামার', 'Total Farms')}</span>
            <div className="w-7 h-7 rounded-lg bg-forest-800 flex items-center justify-center text-gold-400">
              <Sprout className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-cream-50">
            {lang === 'bn' ? toBnDigits(summary?.total_farms || farms.length) : (summary?.total_farms || farms.length)}
          </div>
        </div>

        {/* Active Crops */}
        <div className="rounded-2xl p-4 bg-forest-900/80 border border-forest-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-sage-400 font-bengali">{t('চলমান ফসল', 'Active Crops')}</span>
            <div className="w-7 h-7 rounded-lg bg-forest-800 flex items-center justify-center text-emerald-400">
              <Layers className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-cream-50">
            {lang === 'bn' ? toBnDigits(summary?.active_crops || crops.length) : (summary?.active_crops || crops.length)}
          </div>
        </div>

        {/* Today's Tasks */}
        <div className="rounded-2xl p-4 bg-forest-900/80 border border-forest-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gold-400 font-bengali font-semibold">{t('আজকের কাজ', "Today's Tasks")}</span>
            <div className="w-7 h-7 rounded-lg bg-gold-500/20 flex items-center justify-center text-gold-400">
              <Clock className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-gold-300">
            {lang === 'bn' ? toBnDigits(summary?.today_tasks_count || 0) : (summary?.today_tasks_count || 0)}
          </div>
        </div>

        {/* Upcoming Tasks */}
        <div className="rounded-2xl p-4 bg-forest-900/80 border border-forest-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-sage-400 font-bengali">{t('আসন্ন কাজ', 'Upcoming')}</span>
            <div className="w-7 h-7 rounded-lg bg-forest-800 flex items-center justify-center text-sky-400">
              <CalendarIcon className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-cream-50">
            {lang === 'bn' ? toBnDigits(summary?.upcoming_tasks_count || 0) : (summary?.upcoming_tasks_count || 0)}
          </div>
        </div>

        {/* Overdue Tasks */}
        <div className="rounded-2xl p-4 bg-forest-900/80 border border-forest-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-rose-400 font-bengali font-semibold">{t('মেয়াদোত্তীর্ণ', 'Overdue')}</span>
            <div className="w-7 h-7 rounded-lg bg-rose-500/20 flex items-center justify-center text-rose-400">
              <AlertTriangle className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-rose-400">
            {lang === 'bn' ? toBnDigits(summary?.overdue_tasks_count || 0) : (summary?.overdue_tasks_count || 0)}
          </div>
        </div>

        {/* Completed Tasks */}
        <div className="rounded-2xl p-4 bg-forest-900/80 border border-forest-800 shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-sage-400 font-bengali">{t('সম্পন্ন কাজ', 'Completed')}</span>
            <div className="w-7 h-7 rounded-lg bg-forest-800 flex items-center justify-center text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            {lang === 'bn' ? toBnDigits(summary?.completed_tasks_count || 0) : (summary?.completed_tasks_count || 0)}
          </div>
        </div>
      </div>

      {/* Contextual AI Models Recommendation Strip */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-forest-900/90 via-forest-950 to-forest-900/90 border border-forest-750 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs font-bengali">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gold-400/20 text-gold-400 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold text-cream-100 flex items-center gap-1.5">
              <span>{t('কৃষি এআই সহায়তা ও সংশ্লিষ্ট মডেল', 'Contextual AI Models & Agricultural Intelligence')}</span>
            </span>
            <p className="text-[11px] text-sage-300 mt-0.5">
              {t('ক্যালেন্ডারের ফসল ও খামারের তথ্যের ভিত্তিতে প্রাসঙ্গিক এআই মডেল ব্যবহার করুন:', 'Launch trained AI diagnostic & forecasting models matching your current crops:')}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {(!selectedCropId || selectedCropId === 'all' || crops.some(c => c.crop_name.toLowerCase().includes('rice') || c.crop_name.includes('ধান'))) && (
            <>
              <button
                type="button"
                onClick={() => onNavigateToModel?.('rice_disease')}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-forest-800 hover:bg-forest-750 text-emerald-300 border border-emerald-500/30 transition-colors cursor-pointer"
              >
                <span>🌾 {t('ধানের রোগ নির্ণয়', 'Rice Leaf Disease')}</span>
              </button>
              <button
                type="button"
                onClick={() => onNavigateToModel?.('boro_rice_price')}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-forest-800 hover:bg-forest-750 text-gold-300 border border-gold-400/30 transition-colors cursor-pointer"
              >
                <span>📈 {t('বোরো ধান বাজারদর', 'Boro Rice Price')}</span>
              </button>
            </>
          )}

          {(!selectedCropId || selectedCropId === 'all' || crops.some(c => c.crop_name.toLowerCase().includes('tomato') || c.crop_name.includes('টমেটো'))) && (
            <>
              <button
                type="button"
                onClick={() => onNavigateToModel?.('tomato_disease_v3')}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-forest-800 hover:bg-forest-750 text-emerald-300 border border-emerald-500/30 transition-colors cursor-pointer"
              >
                <span>🍅 {t('টমেটোর রোগ সনাক্তকরণ', 'Tomato Disease')}</span>
              </button>
              <button
                type="button"
                onClick={() => onNavigateToModel?.('tomato_price')}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-forest-800 hover:bg-forest-750 text-gold-300 border border-gold-400/30 transition-colors cursor-pointer"
              >
                <span>📊 {t('টমেটো বাজারদর', 'Tomato Price')}</span>
              </button>
            </>
          )}

          <button
            type="button"
            onClick={() => onNavigateToModel?.('crop_recommendation')}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-forest-850 hover:bg-forest-800 text-cream-100 border border-forest-700 transition-colors cursor-pointer"
          >
            <span>🌱 {t('উপযুক্ত ফসল নির্বাচন', 'Crop Recommend')}</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigateToModel?.('regional_crop_yield')}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-forest-850 hover:bg-forest-800 text-cream-100 border border-forest-700 transition-colors cursor-pointer"
          >
            <span>⚖️ {t('আঞ্চলিক ফলন', 'Regional Yield')}</span>
          </button>

          <button
            type="button"
            onClick={() => onNavigateToModel?.('flood_susceptibility')}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-forest-850 hover:bg-forest-800 text-sky-300 border border-sky-500/30 transition-colors cursor-pointer"
          >
            <span>🌊 {t('বন্যা ঝুঁকি', 'Flood Risk')}</span>
          </button>
        </div>
      </div>

      {/* Main Tab 1: Calendar View & Tasks */}
      {mainTab === 'calendar' && (
        <div className="space-y-6">
          {/* Phase F4C: Weather Advisory Alert Strip */}
          {weatherAdvisories.length > 0 && (
            <WeatherAdvisoryBanner
              advisories={weatherAdvisories}
              onOpenRescheduleModal={(adv) => {
                setSelectedWeatherAdvisory(adv);
                setWeatherRescheduleDate(adv.task_due_date);
                setIsWeatherRescheduleOpen(true);
              }}
            />
          )}

          {/* Control Toolbar: View Switcher, Month Navigation & Filters */}
          <div className="rounded-2xl p-4 bg-forest-900/80 border border-forest-800 shadow-md flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Left: View Toggle & Month Navigator */}
        <div className="flex flex-wrap items-center gap-3">
          {/* View Mode Buttons */}
          <div className="inline-flex rounded-xl bg-forest-950 p-1 border border-forest-800">
            <button
              type="button"
              onClick={() => setViewMode('month')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bengali font-semibold transition-colors cursor-pointer ${
                viewMode === 'month'
                  ? 'bg-gold-500 text-forest-950 shadow-sm'
                  : 'text-sage-300 hover:text-cream-50'
              }`}
            >
              {t('মাসিক ভিউ', 'Month')}
            </button>
            <button
              type="button"
              onClick={() => setViewMode('week')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bengali font-semibold transition-colors cursor-pointer ${
                viewMode === 'week'
                  ? 'bg-gold-500 text-forest-950 shadow-sm'
                  : 'text-sage-300 hover:text-cream-50'
              }`}
            >
              {t('সাপ্তাহিক ভিউ', 'Week')}
            </button>
            <button
              type="button"
              onClick={() => setViewMode('agenda')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bengali font-semibold transition-colors cursor-pointer ${
                viewMode === 'agenda'
                  ? 'bg-gold-500 text-forest-950 shadow-sm'
                  : 'text-sage-300 hover:text-cream-50'
              }`}
            >
              {t('কাজের তালিকা (এজেন্ডা)', 'Agenda / List')}
            </button>
          </div>

          {/* Month Stepper (For Month & Week Views) */}
          {viewMode !== 'agenda' && (
            <div className="flex items-center gap-2 bg-forest-950 px-2 py-1 rounded-xl border border-forest-800">
              <button
                type="button"
                onClick={handlePrevMonth}
                aria-label="Previous Month"
                className="p-1 rounded-lg hover:bg-forest-800 text-sage-300 hover:text-cream-50 transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <span className="text-xs font-bengali font-bold text-cream-100 min-w-[120px] text-center">
                {lang === 'bn'
                  ? `${BENGALI_MONTHS[currentDate.getMonth()]} ${toBnDigits(currentDate.getFullYear())}`
                  : `${currentDate.toLocaleString('default', { month: 'long' })} ${currentDate.getFullYear()}`}
              </span>

              <button
                type="button"
                onClick={handleNextMonth}
                aria-label="Next Month"
                className="p-1 rounded-lg hover:bg-forest-800 text-sage-300 hover:text-cream-50 transition-colors cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={handleToday}
                className="ml-1 px-2 py-0.5 rounded-md bg-forest-800 hover:bg-forest-750 text-[11px] font-bengali font-semibold text-gold-300 transition-colors cursor-pointer"
              >
                {t('আজকে যান', 'Today')}
              </button>
            </div>
          )}
        </div>

        {/* Right: Farm, Category & Status Filters */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Farm Filter */}
          <select
            value={selectedFarmId}
            onChange={(e) => setSelectedFarmId(e.target.value === 'all' ? 'all' : Number(e.target.value))}
            className="px-3 py-1.5 rounded-xl bg-forest-950 border border-forest-800 text-xs font-bengali text-cream-100 focus:outline-none focus:border-gold-500 cursor-pointer"
          >
            <option value="all">{t('সব খামার', 'All Farms')}</option>
            {farms.map((farm) => (
              <option key={farm.id} value={farm.id}>
                {farm.name} ({farm.upazila}, {farm.district})
              </option>
            ))}
          </select>

          {/* Crop Filter */}
          <select
            value={selectedCropId}
            onChange={(e) => setSelectedCropId(e.target.value === 'all' ? 'all' : Number(e.target.value))}
            className="px-3 py-1.5 rounded-xl bg-forest-950 border border-forest-800 text-xs font-bengali text-cream-100 focus:outline-none focus:border-gold-500 cursor-pointer"
          >
            <option value="all">{t('সব ফসল', 'All Crops')}</option>
            {crops.map((crop) => (
              <option key={crop.id} value={crop.id}>
                {crop.crop_name} {crop.variety ? `(${crop.variety})` : ''} - {crop.season}
              </option>
            ))}
          </select>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-forest-950 border border-forest-800 text-xs font-bengali text-cream-100 focus:outline-none focus:border-gold-500 cursor-pointer"
          >
            <option value="all">{t('সব কাজ / ধরন', 'All Categories')}</option>
            {TASK_CATEGORIES.map((c) => (
              <option key={c.id} value={c.id}>
                {lang === 'bn' ? c.labelBn : c.labelEn}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-forest-950 border border-forest-800 text-xs font-bengali text-cream-100 focus:outline-none focus:border-gold-500 cursor-pointer"
          >
            <option value="all">{t('সব অবস্থা', 'All Statuses')}</option>
            <option value="pending">{t('বাকি কাজ (Pending)', 'Pending')}</option>
            <option value="completed">{t('সম্পন্ন কাজ (Completed)', 'Completed')}</option>
            <option value="overdue">{t('মেয়াদোত্তীর্ণ (Overdue)', 'Overdue')}</option>
          </select>

          {/* Refresh Button */}
          <button
            type="button"
            onClick={loadAllData}
            title={t('পুনরায় লোড করুন', 'Reload Data')}
            className="p-2 rounded-xl bg-forest-950 hover:bg-forest-800 border border-forest-800 text-gold-400 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main View Area */}
      {farms.length === 0 && !isLoading ? (
        /* Empty State: No Farm Profiles */
        <div className="rounded-3xl p-8 sm:p-12 bg-forest-900/60 border border-forest-800 text-center max-w-xl mx-auto shadow-xl">
          <div className="w-16 h-16 rounded-2xl bg-gold-400/10 border border-gold-400/30 flex items-center justify-center text-gold-400 mx-auto mb-4">
            <Sprout className="w-8 h-8" />
          </div>

          <h3 className="font-bengali font-bold text-xl text-cream-50 mb-2">
            {t('আপনার কোনো খামার প্রোফাইল নেই', 'No Farm Profiles Registered Yet')}
          </h3>

          <p className="font-bengali text-xs sm:text-sm text-sage-300 leading-relaxed mb-6">
            {t(
              'স্মার্ট কৃষি ক্যালেন্ডার ব্যবহার করতে প্রথমে আপনার জমির অবস্থান (বিভাগ, জেলা, উপজেলা), আয়তন এবং মাটির ধরন দিয়ে একটি খামার প্রোফাইল তৈরি করুন।',
              'To utilize the smart agricultural calendar, first register your farm profile with its location (division, district, upazila), area, and soil characteristics.'
            )}
          </p>

          <button
            type="button"
            onClick={() => setIsAddFarmOpen(true)}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gold-500 hover:bg-gold-400 text-forest-950 text-sm font-bengali font-bold transition-all cursor-pointer shadow-lg hover:scale-105"
          >
            <Plus className="w-4 h-4" />
            <span>{t('প্রথম খামার প্রোফাইল তৈরি করুন', 'Create First Farm Profile')}</span>
          </button>
        </div>
      ) : (
        <>
          {/* VIEW 1: MONTH GRID VIEW */}
          {viewMode === 'month' && (
            <div className="rounded-3xl bg-forest-900/80 border border-forest-800 overflow-hidden shadow-xl">
              {/* Day of Week Header (Saturday to Friday) */}
              <div className="grid grid-cols-7 bg-forest-950 border-b border-forest-800 text-center py-2.5 text-xs font-bengali font-bold text-gold-400">
                {lang === 'bn'
                  ? BENGALI_WEEKDAYS.map((w, idx) => (
                      <div key={idx} className={idx === 6 ? 'text-rose-400' : ''}>
                        {w}
                      </div>
                    ))
                  : ENGLISH_WEEKDAYS.map((w, idx) => (
                      <div key={idx} className={idx === 6 ? 'text-rose-400' : ''}>
                        {w}
                      </div>
                    ))}
              </div>

              {/* Day Cells Grid */}
              <div className="grid grid-cols-7 auto-rows-fr divide-x divide-y divide-forest-800/80">
                {calendarGridDays.map((day, idx) => {
                  const dayTasks = filteredTasks.filter((t) => t.due_date === day.dateStr);

                  return (
                    <div
                      key={idx}
                      onClick={() => openAddTaskForDate(day.dateStr)}
                      className={`min-h-[95px] sm:min-h-[125px] p-1.5 sm:p-2.5 flex flex-col justify-between transition-colors cursor-pointer group hover:bg-forest-850/60 ${
                        !day.isCurrentMonth
                          ? 'bg-forest-950/40 text-sage-600'
                          : 'bg-transparent text-cream-100'
                      } ${day.isToday ? 'ring-2 ring-gold-400/80 ring-inset bg-gold-400/5' : ''}`}
                    >
                      {/* Day Header */}
                      <div className="flex items-center justify-between">
                        <span
                          className={`text-xs font-mono font-bold px-1.5 py-0.5 rounded-md ${
                            day.isToday
                              ? 'bg-gold-500 text-forest-950 font-black shadow-xs'
                              : day.isCurrentMonth
                              ? 'text-cream-100'
                              : 'text-sage-500'
                          }`}
                        >
                          {lang === 'bn' ? toBnDigits(day.dayNum) : day.dayNum}
                        </span>

                        {dayTasks.length > 0 && (
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-forest-800 text-gold-300 border border-forest-700">
                            {lang === 'bn' ? toBnDigits(dayTasks.length) : dayTasks.length}
                          </span>
                        )}
                      </div>

                      {/* Task chips list */}
                      <div className="space-y-1 my-1 overflow-hidden">
                        {dayTasks.slice(0, 2).map((task) => {
                          const meta = getCategoryMeta(task.category);
                          const isDone = task.status === 'completed';

                          return (
                            <div
                              key={task.id}
                              onClick={(e) => {
                                e.stopPropagation();
                                openRescheduleModal(task);
                              }}
                              className={`px-1.5 py-0.5 rounded text-[10px] truncate border font-bengali flex items-center gap-1 cursor-pointer transition-all hover:scale-[1.02] ${
                                isDone
                                  ? 'bg-forest-950/80 text-sage-400 border-forest-750 line-through'
                                  : task.is_overdue
                                  ? 'bg-rose-950/80 text-rose-200 border-rose-600/50'
                                  : `${meta.color}`
                              }`}
                            >
                              <span
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleToggleTaskStatus(task);
                                }}
                                className="hover:scale-125 transition-transform"
                              >
                                {isDone ? (
                                  <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400 shrink-0" />
                                ) : (
                                  <Circle className="w-2.5 h-2.5 text-sage-400 shrink-0" />
                                )}
                              </span>
                              <span className="truncate">{task.title}</span>
                            </div>
                          );
                        })}

                        {dayTasks.length > 2 && (
                          <div className="text-[9px] font-bengali text-gold-400 font-semibold px-1">
                            +{lang === 'bn' ? toBnDigits(dayTasks.length - 2) : dayTasks.length - 2} {t('আরও কাজ', 'more')}
                          </div>
                        )}
                      </div>

                      {/* Quick Add icon visible on hover */}
                      <div className="opacity-0 group-hover:opacity-100 text-right transition-opacity">
                        <span className="text-[10px] text-gold-400 font-mono">+ {t('কাজ', 'Add')}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* VIEW 2: WEEK VIEW */}
          {viewMode === 'week' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
                {calendarGridDays.slice(0, 7).map((day, idx) => {
                  const dayTasks = filteredTasks.filter((t) => t.due_date === day.dateStr);

                  return (
                    <div
                      key={idx}
                      className={`rounded-2xl p-4 bg-forest-900/80 border flex flex-col justify-between shadow-md ${
                        day.isToday ? 'border-gold-400 bg-gold-400/5 ring-1 ring-gold-400' : 'border-forest-800'
                      }`}
                    >
                      <div className="border-b border-forest-800 pb-2.5 mb-3 flex items-center justify-between">
                        <div>
                          <span className="text-xs font-bengali font-bold text-gold-400 block">
                            {lang === 'bn' ? BENGALI_WEEKDAYS[idx] : ENGLISH_WEEKDAYS[idx]}
                          </span>
                          <span className="text-[11px] font-mono text-sage-300">{day.dateStr}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => openAddTaskForDate(day.dateStr)}
                          className="p-1 rounded-lg bg-forest-800 hover:bg-forest-750 text-gold-300 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="space-y-2 flex-1">
                        {dayTasks.length === 0 ? (
                          <p className="text-[11px] text-sage-500 font-bengali italic py-4 text-center">
                            {t('কোনো কাজ নেই', 'No tasks')}
                          </p>
                        ) : (
                          dayTasks.map((task) => {
                            const isDone = task.status === 'completed';
                            return (
                              <div
                                key={task.id}
                                className={`p-2.5 rounded-xl border text-xs font-bengali space-y-1.5 transition-all ${
                                  isDone
                                    ? 'bg-forest-950/60 border-forest-800 text-sage-400'
                                    : task.is_overdue
                                    ? 'bg-rose-950/60 border-rose-600/50 text-rose-100'
                                    : 'bg-forest-950 border-forest-750 text-cream-100'
                                }`}
                              >
                                <div className="flex items-start justify-between gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => handleToggleTaskStatus(task)}
                                    className="mt-0.5 text-sage-400 hover:text-emerald-400 cursor-pointer"
                                  >
                                    {isDone ? (
                                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                    ) : (
                                      <Circle className="w-4 h-4" />
                                    )}
                                  </button>
                                  <span className={`font-semibold flex-1 ${isDone ? 'line-through' : ''}`}>
                                    {task.title}
                                  </span>
                                </div>

                                <div className="flex items-center justify-between text-[10px] text-sage-400 pt-1">
                                  <span>{task.due_time || '08:00'}</span>
                                  {getPriorityBadge(task.priority)}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* VIEW 3: AGENDA / TASK LIST VIEW */}
          {viewMode === 'agenda' && (
            <div className="space-y-6">
              {/* Overdue Section */}
              {summary && summary.overdue_tasks.length > 0 && (
                <div className="rounded-3xl p-5 sm:p-6 bg-rose-950/20 border border-rose-500/40 shadow-xl space-y-3">
                  <div className="flex items-center gap-2 text-rose-400 font-bengali font-bold text-sm sm:text-base">
                    <AlertTriangle className="w-4 h-4" />
                    <span>
                      {t('মেয়াদোত্তীর্ণ কাজসমূহ', 'Overdue Tasks')} ({lang === 'bn' ? toBnDigits(summary.overdue_tasks.length) : summary.overdue_tasks.length})
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {summary.overdue_tasks.map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        onToggleStatus={() => handleToggleTaskStatus(task)}
                        onReschedule={() => openRescheduleModal(task)}
                        onDelete={() => handleDeleteTask(task.id)}
                        t={t}
                        lang={lang}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Today Section */}
              <div className="rounded-3xl p-5 sm:p-6 bg-forest-900/80 border border-forest-800 shadow-xl space-y-3">
                <div className="flex items-center gap-2 text-gold-400 font-bengali font-bold text-sm sm:text-base">
                  <Clock className="w-4 h-4" />
                  <span>
                    {t('আজকের করণীয় কাজ', "Today's Scheduled Tasks")} ({lang === 'bn' ? toBnDigits(summary?.today_tasks.length || 0) : summary?.today_tasks.length || 0})
                  </span>
                </div>

                {summary && summary.today_tasks.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {summary.today_tasks.map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        onToggleStatus={() => handleToggleTaskStatus(task)}
                        onReschedule={() => openRescheduleModal(task)}
                        onDelete={() => handleDeleteTask(task.id)}
                        t={t}
                        lang={lang}
                      />
                    ))}
                  </div>
                ) : (
                  <p className="text-xs font-bengali text-sage-400 py-3">
                    {t('আজকের জন্য কোনো নির্ধারিত কাজ নেই। নতুন কাজ যোগ করতে উপরের বোতাম ব্যবহার করুন।', "No tasks scheduled for today. Use the '+ Add New Task' button to schedule tasks.")}
                  </p>
                )}
              </div>

              {/* All / Upcoming Filtered Tasks */}
              <div className="rounded-3xl p-5 sm:p-6 bg-forest-900/80 border border-forest-800 shadow-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-cream-100 font-bengali font-bold text-sm sm:text-base">
                    <CalendarIcon className="w-4 h-4 text-emerald-400" />
                    <span>
                      {t('সকল তালিকাভুক্ত কাজ', 'All Scheduled Tasks')} ({lang === 'bn' ? toBnDigits(filteredTasks.length) : filteredTasks.length})
                    </span>
                  </div>
                </div>

                {filteredTasks.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-xs font-bengali text-sage-400">
                      {t('কোনো কাজ পাওয়া যায়নি। ফিল্টার পরিবর্তন করুন বা নতুন কাজ যুক্ত করুন।', 'No tasks found. Try changing filters or add a new task.')}
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {filteredTasks.map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        onToggleStatus={() => handleToggleTaskStatus(task)}
                        onReschedule={() => openRescheduleModal(task)}
                        onDelete={() => handleDeleteTask(task.id)}
                        t={t}
                        lang={lang}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </>
      )}

          {/* Scientific Provenance Quick Reference Badge (Phase F4A & F4B) */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3.5 rounded-2xl bg-forest-950/70 border border-forest-800/80 text-xs text-sage-300 font-bengali">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                <strong>BARC • BRRI • BAMIS • DAE</strong> {t('স্বীকৃত গবেষণা মানদণ্ড অনুযায়ী পরিচালিত', 'verified agricultural research standards')}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setMainTab('provenance')}
              className="text-gold-400 hover:text-gold-300 underline text-[11px] cursor-pointer"
            >
              {t('গবেষণা উৎস ও তথ্যপ্রমাণ দেখুন →', 'View Research Standards & Provenance →')}
            </button>
          </div>
        </div>
      )}

      {/* Main Tab 2: Growth Timeline */}
      {mainTab === 'timeline' && (
        <div className="space-y-6 animate-fade-in-up">
          {/* Template Selector Bar */}
          <div className="p-4 rounded-2xl bg-forest-900/90 border border-forest-750 flex flex-wrap items-center justify-between gap-3 text-xs font-bengali">
            <div className="flex items-center gap-3">
              <Sprout className="w-5 h-5 text-emerald-400" />
              <div>
                <span className="text-sage-400 block text-[11px]">{t('ফসল বা টেমপ্লেট নির্বাচন করুন:', 'Select Crop / Template:')}</span>
                <select
                  value={selectedTimelineTemplate?.template_id || (templates[0]?.template_id || '')}
                  onChange={(e) => {
                    const tpl = templates.find((t) => t.template_id === e.target.value);
                    if (tpl) setSelectedTimelineTemplate(tpl);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-forest-950 border border-forest-750 text-cream-50 font-bold focus:outline-none focus:border-gold-500 mt-1"
                >
                  {templates.map((t) => (
                    <option key={t.template_id} value={t.template_id}>
                      {t.crop_bn} ({t.season_bn} মৌসুম) • {t.variety}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  handleOpenScheduleGenerator();
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-400 hover:to-gold-500 text-forest-950 text-xs font-bold border border-gold-400 shadow-md cursor-pointer transition-all hover:scale-[1.02]"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{t('এই ফসলের পরিকল্পনা তৈরি করুন', 'Generate for this Crop')}</span>
              </button>
            </div>
          </div>

          {/* Growth Timeline Render */}
          <GrowthTimeline
            template={selectedTimelineTemplate || (templates.length > 0 ? templates[0] : null)}
            plantingDate={formatDateStr(new Date())}
          />
        </div>
      )}

      {/* Main Tab 3: Research Provenance & Standards */}
      {mainTab === 'provenance' && (
        <div className="space-y-6 animate-fade-in-up font-bengali">
          {/* Header info */}
          <div className="p-6 rounded-3xl bg-forest-950 border border-forest-800 text-cream-50 shadow-md">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-4 pb-4 border-b border-forest-800/80">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-forest-800 border border-forest-700 flex items-center justify-center text-gold-400 shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base sm:text-lg text-cream-50">
                    {t('বাংলাদেশ কৃষি গবেষণা কাউন্সিল ও গবেষণা প্রতিষ্ঠানের স্বীকৃত মানদণ্ড', 'National Agricultural Research Standards & Provenance')}
                  </h3>
                  <p className="text-xs text-sage-300">
                    {t('সকল তথ্য BRRI, BARI, BAMIS ও DAE এর আনুষ্ঠানিক প্রকাশনা থেকে সংগ্রহ ও যাচাইকৃত', 'All schedules are sourced and verified from BRRI, BARI, BAMIS and DAE publications')}
                  </p>
                </div>
              </div>

              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-forest-900 border border-forest-750 text-gold-300 text-xs font-mono">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span>Phase F4B Verified • 100% Authentic</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {templates.map((tpl) => (
                <div
                  key={tpl.template_id}
                  className="p-5 rounded-2xl bg-forest-900/90 border border-forest-750 flex flex-col justify-between space-y-4 hover:border-gold-500/40 transition-all shadow-md"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[11px] font-mono text-gold-400 font-bold bg-gold-400/10 px-2 py-0.5 rounded border border-gold-400/20">
                        {tpl.template_id}
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                        {tpl.season_bn} মৌসুম
                      </span>
                    </div>

                    <h4 className="font-bold text-cream-50 text-base">
                      {tpl.crop_bn} <span className="text-sage-300 text-xs font-normal">({tpl.crop})</span>
                    </h4>
                    <p className="text-xs text-gold-300 mt-1 font-mono">
                      {tpl.variety}
                    </p>

                    <div className="mt-3 space-y-1.5 text-xs text-sage-300">
                      <p>
                        <strong className="text-cream-100">{t('উৎস সংস্থা:', 'Agency:')}</strong> {tpl.source_agency}
                      </p>
                      <p>
                        <strong className="text-cream-100">{t('সংস্করণ / প্রকাশনা:', 'Version:')}</strong> {tpl.source_version}
                      </p>
                      <p>
                        <strong className="text-cream-100">{t('রোপণ সময়কাল:', 'Sowing Window:')}</strong> {tpl.recommended_sowing_window}
                      </p>
                      <p className="text-[11px] text-amber-300/90 bg-amber-950/30 p-2 rounded-xl border border-amber-900/40 mt-2">
                        <strong>{t('সীমাবদ্ধতা:', 'Limitations:')}</strong> {tpl.limitations}
                      </p>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-forest-800 flex items-center justify-between gap-2">
                    <a
                      href={tpl.source_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300 underline"
                    >
                      <span>{t('সরকারি সূত্র দেখুন', 'View Source')}</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>

                    <button
                      type="button"
                      onClick={() => {
                        handleOpenScheduleGenerator();
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-forest-800 hover:bg-forest-750 text-gold-300 text-xs font-semibold border border-forest-700 cursor-pointer transition-colors"
                    >
                      <Sparkles className="w-3 h-3 text-gold-400" />
                      <span>{t('পরিকল্পনা তৈরি', 'Generate')}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Return to Dashboard */}
      {onBackToDashboard && (
        <div className="pt-2 text-center">
          <button
            type="button"
            onClick={onBackToDashboard}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-forest-800 hover:bg-forest-750 text-gold-300 text-xs font-bengali font-semibold border border-forest-700 transition-colors cursor-pointer shadow-sm"
          >
            <span>{t('ড্যাশবোর্ডে ফিরে যান', 'Return to Dashboard')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Tab 4: Weather Dashboard & Forecast */}
      {mainTab === 'weather' && (
        <div className="space-y-6 animate-fade-in-up">
          <WeatherDashboardPanel
            farms={farms}
            selectedFarmId={selectedFarmId === 'all' ? (farms[0]?.id ?? null) : selectedFarmId}
            onSelectFarm={(fId) => {
              setSelectedFarmId(fId);
              weatherApi.getAdvisories(fId).then((a) => setWeatherAdvisories(a.advisories || [])).catch(() => {});
            }}
            onNavigateToModel={(mId) => onNavigateToModel?.(mId)}
          />
        </div>
      )}

      {/* =========================================================================
          MODAL 1: ADD FARM MODAL
          ========================================================================= */}
      {isAddFarmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-950/80 backdrop-blur-sm animate-fade-in-up">
          <div className="bg-forest-950 border border-forest-800 rounded-3xl w-full max-w-lg p-6 text-cream-50 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-forest-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-gold-400/20 text-gold-400 flex items-center justify-center">
                  <Sprout className="w-4 h-4" />
                </div>
                <h3 className="font-bengali font-bold text-lg text-cream-50">
                  {t('নতুন খামার প্রোফাইল যোগ করুন', 'Add New Farm Profile')}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddFarmOpen(false)}
                className="p-1 rounded-lg hover:bg-forest-850 text-sage-400 hover:text-cream-50"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateFarm} className="space-y-4 pt-4 text-xs font-bengali">
              {/* Farm Name */}
              <div>
                <label className="block text-sage-300 font-semibold mb-1">
                  {t('খামারের নাম *', 'Farm Name *')}
                </label>
                <input
                  type="text"
                  required
                  placeholder={t('যেমন: স্বপ্নছোঁয়া ডেইরি ও কৃষি খামার', 'e.g. Green Valley Farm')}
                  value={farmForm.name}
                  onChange={(e) => setFarmForm({ ...farmForm, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                />
              </div>

              {/* Division & District */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('বিভাগ *', 'Division *')}
                  </label>
                  <select
                    value={farmForm.division}
                    onChange={(e) => {
                      const div = e.target.value;
                      const districtList = divisions[div] || [];
                      setFarmForm({
                        ...farmForm,
                        division: div,
                        district: districtList[0] || '',
                      });
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  >
                    {Object.keys(divisions).map((div) => (
                      <option key={div} value={div}>
                        {div}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('জেলা *', 'District *')}
                  </label>
                  <select
                    value={farmForm.district}
                    onChange={(e) => setFarmForm({ ...farmForm, district: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  >
                    {(divisions[farmForm.division] || []).map((dst) => (
                      <option key={dst} value={dst}>
                        {dst}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Upazila & Village */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('উপজেলা *', 'Upazila *')}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder={t('যেমন: সাভার', 'e.g. Savar')}
                    value={farmForm.upazila}
                    onChange={(e) => setFarmForm({ ...farmForm, upazila: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  />
                </div>

                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('গ্রাম / মৌজা (ঐচ্ছিক)', 'Village / Locality (Optional)')}
                  </label>
                  <input
                    type="text"
                    placeholder={t('যেমন: বনগাঁও', 'e.g. Bongaon')}
                    value={farmForm.village || ''}
                    onChange={(e) => setFarmForm({ ...farmForm, village: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  />
                </div>
              </div>

              {/* Land Area & Unit */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('জমির পরিমাণ *', 'Land Area *')}
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="0.1"
                    required
                    value={farmForm.area}
                    onChange={(e) => setFarmForm({ ...farmForm, area: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  />
                </div>

                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('পরিমাপের একক *', 'Measurement Unit *')}
                  </label>
                  <select
                    value={farmForm.area_unit}
                    onChange={(e) => setFarmForm({ ...farmForm, area_unit: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  >
                    <option value="Decimal">{t('শতক / ডেসিমাল (Decimal)', 'Decimal')}</option>
                    <option value="Bigha">{t('বিঘা (Bigha = ৩৩ শতক)', 'Bigha (33 Decimals)')}</option>
                    <option value="Acre">{t('একর (Acre = ১০০ শতক)', 'Acre (100 Decimals)')}</option>
                    <option value="Hectare">{t('হেক্টর (Hectare)', 'Hectare')}</option>
                    <option value="Katha">{t('কাঠা (Katha)', 'Katha')}</option>
                  </select>
                </div>
              </div>

              {/* Soil Type */}
              <div>
                <label className="block text-sage-300 font-semibold mb-1">
                  {t('মাটির ধরন', 'Soil Type')}
                </label>
                <select
                  value={farmForm.soil_type || 'Loam'}
                  onChange={(e) => setFarmForm({ ...farmForm, soil_type: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                >
                  <option value="Loam">{t('দোআঁশ মাটি (Loam Soil)', 'Loam Soil')}</option>
                  <option value="Sandy Loam">{t('বেলে দোআঁশ (Sandy Loam)', 'Sandy Loam')}</option>
                  <option value="Clay">{t('এঁটেল মাটি (Clay Soil)', 'Clay Soil')}</option>
                  <option value="Alluvial">{t('পলিমাটি (Alluvial Soil)', 'Alluvial Soil')}</option>
                </select>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sage-300 font-semibold mb-1">
                  {t('বিশেষ বিবরণ বা নোট', 'Agronomic Notes (Optional)')}
                </label>
                <textarea
                  rows={2}
                  placeholder={t('যেমন: সেচ সুবিধা আছে, নিচু জমি...', 'e.g. Deep tubewell available...')}
                  value={farmForm.notes || ''}
                  onChange={(e) => setFarmForm({ ...farmForm, notes: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-3 border-t border-forest-800">
                <button
                  type="button"
                  onClick={() => setIsAddFarmOpen(false)}
                  className="px-4 py-2 rounded-xl bg-forest-900 hover:bg-forest-850 text-sage-300"
                >
                  {t('বাতিল', 'Cancel')}
                </button>
                <button
                  type="submit"
                  disabled={isActionPending}
                  className="px-5 py-2 rounded-xl bg-gold-500 hover:bg-gold-400 text-forest-950 font-bold disabled:opacity-50 cursor-pointer shadow-md"
                >
                  {isActionPending ? t('সংরক্ষণ হচ্ছে...', 'Saving...') : t('খামার সংরক্ষণ করুন', 'Save Farm Profile')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 2: ADD CROP MODAL
          ========================================================================= */}
      {isAddCropOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-950/80 backdrop-blur-sm animate-fade-in-up">
          <div className="bg-forest-950 border border-forest-800 rounded-3xl w-full max-w-lg p-6 text-cream-50 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-forest-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-emerald-400/20 text-emerald-400 flex items-center justify-center">
                  <Layers className="w-4 h-4" />
                </div>
                <h3 className="font-bengali font-bold text-lg text-cream-50">
                  {t('খামারে ফসল চক্র নির্ধারণ করুন', 'Add Crop to Farm')}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddCropOpen(false)}
                className="p-1 rounded-lg hover:bg-forest-850 text-sage-400 hover:text-cream-50"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCrop} className="space-y-4 pt-4 text-xs font-bengali">
              {/* Select Farm */}
              <div>
                <label className="block text-sage-300 font-semibold mb-1">
                  {t('খামার নির্বাচন করুন *', 'Select Farm *')}
                </label>
                <select
                  value={cropForm.farm_id}
                  onChange={(e) => setCropForm({ ...cropForm, farm_id: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                >
                  {farms.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name} ({f.upazila}, {f.district})
                    </option>
                  ))}
                </select>
              </div>

              {/* Crop Name & Variety */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('ফসলের নাম *', 'Crop Name *')}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder={t('যেমন: ধান (Rice)', 'e.g. Rice, Tomato')}
                    value={cropForm.crop_name}
                    onChange={(e) => setCropForm({ ...cropForm, crop_name: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  />
                </div>

                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('জাত বা ভ্যারাইটি', 'Variety')}
                  </label>
                  <input
                    type="text"
                    placeholder={t('যেমন: ব্রি ধান-২৮', 'e.g. BRRI Dhan-28')}
                    value={cropForm.variety || ''}
                    onChange={(e) => setCropForm({ ...cropForm, variety: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  />
                </div>
              </div>

              {/* Season & Sowing Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('মৌসুম *', 'Season *')}
                  </label>
                  <select
                    value={cropForm.season}
                    onChange={(e) => setCropForm({ ...cropForm, season: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  >
                    <option value="Rabi">{t('রবি (Rabi - শীতকালীন)', 'Rabi (Winter)')}</option>
                    <option value="Kharif-1">{t('খরিপ-১ (Kharif-1 - প্রাক-বর্ষা)', 'Kharif-1')}</option>
                    <option value="Kharif-2">{t('খরিপ-২ (Kharif-2 - বর্ষাকালীন)', 'Kharif-2')}</option>
                    <option value="Year-round">{t('বারোমাসি (Year-round)', 'Year-round')}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('বীজ বপনের তারিখ *', 'Sowing Date *')}
                  </label>
                  <input
                    type="date"
                    required
                    value={cropForm.sowing_date}
                    onChange={(e) => setCropForm({ ...cropForm, sowing_date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  />
                </div>
              </div>

              {/* Transplanting & Expected Harvest */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('চারা রোপণের তারিখ', 'Transplanting Date (Optional)')}
                  </label>
                  <input
                    type="date"
                    value={cropForm.transplanting_date || ''}
                    onChange={(e) => setCropForm({ ...cropForm, transplanting_date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  />
                </div>

                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('সম্ভাব্য ফসল তোলার তারিখ', 'Expected Harvest Date')}
                  </label>
                  <input
                    type="date"
                    value={cropForm.expected_harvest_date || ''}
                    onChange={(e) => setCropForm({ ...cropForm, expected_harvest_date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-3 border-t border-forest-800">
                <button
                  type="button"
                  onClick={() => setIsAddCropOpen(false)}
                  className="px-4 py-2 rounded-xl bg-forest-900 hover:bg-forest-850 text-sage-300"
                >
                  {t('বাতিল', 'Cancel')}
                </button>
                <button
                  type="submit"
                  disabled={isActionPending}
                  className="px-5 py-2 rounded-xl bg-gold-500 hover:bg-gold-400 text-forest-950 font-bold disabled:opacity-50 cursor-pointer shadow-md"
                >
                  {isActionPending ? t('যুক্ত হচ্ছে...', 'Adding...') : t('ফসল নিশ্চিত করুন', 'Confirm Crop')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 3: ADD TASK MODAL
          ========================================================================= */}
      {isAddTaskOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-950/80 backdrop-blur-sm animate-fade-in-up">
          <div className="bg-forest-950 border border-forest-800 rounded-3xl w-full max-w-lg p-6 text-cream-50 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-forest-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-gold-400/20 text-gold-400 flex items-center justify-center">
                  <CalendarIcon className="w-4 h-4" />
                </div>
                <h3 className="font-bengali font-bold text-lg text-cream-50">
                  {t('ক্যালেন্ডারে নতুন কাজ যোগ করুন', 'Add New Agricultural Task')}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddTaskOpen(false)}
                className="p-1 rounded-lg hover:bg-forest-850 text-sage-400 hover:text-cream-50"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-4 pt-4 text-xs font-bengali">
              {/* Select Farm */}
              <div>
                <label className="block text-sage-300 font-semibold mb-1">
                  {t('খামার নির্বাচন করুন *', 'Target Farm *')}
                </label>
                <select
                  value={taskForm.farm_id}
                  onChange={(e) => setTaskForm({ ...taskForm, farm_id: Number(e.target.value), crop_id: null })}
                  className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                >
                  {farms.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name} ({f.district})
                    </option>
                  ))}
                </select>
              </div>

              {/* Select Crop (Optional) */}
              <div>
                <label className="block text-sage-300 font-semibold mb-1">
                  {t('সম্পর্কিত ফসল (ঐচ্ছিক)', 'Associated Crop (Optional)')}
                </label>
                <select
                  value={taskForm.crop_id || ''}
                  onChange={(e) => setTaskForm({ ...taskForm, crop_id: e.target.value ? Number(e.target.value) : null })}
                  className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                >
                  <option value="">{t('নির্দিষ্ট কোনো ফসল নয় (সাধারণ খামার কাজ)', 'No specific crop (General farm task)')}</option>
                  {cropsForSelectedFarm.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.crop_name} {c.variety ? `(${c.variety})` : ''} - {c.season}
                    </option>
                  ))}
                </select>
              </div>

              {/* Task Title */}
              <div>
                <label className="block text-sage-300 font-semibold mb-1">
                  {t('কাজের শিরোনাম *', 'Task Title *')}
                </label>
                <input
                  type="text"
                  required
                  placeholder={t('যেমন: বোরো ধানের জমিতে ২য় কিস্তির ইউরিয়া প্রয়োগ', 'e.g. Apply 2nd urea dose')}
                  value={taskForm.title}
                  onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                />
              </div>

              {/* Category & Priority */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('কাজের ক্যাটাগরি *', 'Category *')}
                  </label>
                  <select
                    value={taskForm.category}
                    onChange={(e) => setTaskForm({ ...taskForm, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  >
                    {TASK_CATEGORIES.map((c) => (
                      <option key={c.id} value={c.id}>
                        {lang === 'bn' ? c.labelBn : c.labelEn}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('অগ্রাধিকার *', 'Priority *')}
                  </label>
                  <select
                    value={taskForm.priority}
                    onChange={(e) => setTaskForm({ ...taskForm, priority: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  >
                    <option value="low">{t('নিম্ন (Low)', 'Low')}</option>
                    <option value="medium">{t('সাধারণ (Normal)', 'Normal')}</option>
                    <option value="high">{t('উচ্চ (High)', 'High')}</option>
                    <option value="urgent">{t('অতি জরুরি (Urgent)', 'Urgent')}</option>
                  </select>
                </div>
              </div>

              {/* Due Date & Due Time */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('নির্ধারিত তারিখ *', 'Due Date *')}
                  </label>
                  <input
                    type="date"
                    required
                    value={taskForm.due_date}
                    onChange={(e) => setTaskForm({ ...taskForm, due_date: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  />
                </div>

                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('সময় (ঐচ্ছিক)', 'Due Time (Optional)')}
                  </label>
                  <input
                    type="time"
                    value={taskForm.due_time || '08:00'}
                    onChange={(e) => setTaskForm({ ...taskForm, due_time: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sage-300 font-semibold mb-1">
                  {t('কাজের বিস্তারিত নির্দেশনা / নোট', 'Instructions / Agronomic Notes')}
                </label>
                <textarea
                  rows={2}
                  placeholder={t('যেমন: জমিতে ২ ইঞ্চি পানি ধরে রেখে সকালে সার ছিটাবেন।', 'e.g. Ensure 2 inches of standing water before broadcasting...')}
                  value={taskForm.notes || ''}
                  onChange={(e) => setTaskForm({ ...taskForm, notes: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-3 border-t border-forest-800">
                <button
                  type="button"
                  onClick={() => setIsAddTaskOpen(false)}
                  className="px-4 py-2 rounded-xl bg-forest-900 hover:bg-forest-850 text-sage-300"
                >
                  {t('বাতিল', 'Cancel')}
                </button>
                <button
                  type="submit"
                  disabled={isActionPending}
                  className="px-5 py-2 rounded-xl bg-gold-500 hover:bg-gold-400 text-forest-950 font-bold disabled:opacity-50 cursor-pointer shadow-md"
                >
                  {isActionPending ? t('যুক্ত হচ্ছে...', 'Adding...') : t('কাজ সংরক্ষণ করুন', 'Save Task')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 4: TASK DETAILS & RESCHEDULE MODAL
          ========================================================================= */}
      {isRescheduleOpen && selectedTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-950/80 backdrop-blur-sm animate-fade-in-up">
          <div className="bg-forest-950 border border-forest-800 rounded-3xl w-full max-w-lg p-6 text-cream-50 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-forest-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-gold-400/20 text-gold-400 flex items-center justify-center">
                  <CalendarClock className="w-4 h-4" />
                </div>
                <h3 className="font-bengali font-bold text-lg text-cream-50">
                  {t('কাজের বিবরণ ও পুনঃনির্ধারণ', 'Task Details & Rescheduling')}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsRescheduleOpen(false)}
                className="p-1 rounded-lg hover:bg-forest-850 text-sage-400 hover:text-cream-50"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="pt-4 space-y-4 text-xs font-bengali">
              {/* Task Header & Status */}
              <div className="p-3.5 rounded-2xl bg-forest-900 border border-forest-750 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[10px] text-sage-400">ID #{selectedTask.id}</span>
                  {getPriorityBadge(selectedTask.priority)}
                </div>
                <h4 className="font-bold text-sm sm:text-base text-cream-50">{selectedTask.title}</h4>
                <div className="flex flex-wrap items-center gap-2 text-[11px] text-sage-300">
                  <span className="inline-flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-gold-400" />
                    {selectedTask.farm_name || `খামার #${selectedTask.farm_id}`}
                  </span>
                  {selectedTask.crop_name && (
                    <span className="inline-flex items-center gap-1">
                      <Layers className="w-3 h-3 text-emerald-400" />
                      {selectedTask.crop_name}
                    </span>
                  )}
                </div>
              </div>

              {/* Status Toggle Action */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-forest-900 border border-forest-800">
                <div className="flex items-center gap-2">
                  <span className="text-sage-300">{t('কাজের বর্তমান অবস্থা:', 'Current Status:')}</span>
                  <span className={`font-bold ${selectedTask.status === 'completed' ? 'text-emerald-400' : 'text-gold-400'}`}>
                    {selectedTask.status === 'completed' ? t('সম্পন্ন', 'Completed') : t('বাকি আছে', 'Pending')}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    handleToggleTaskStatus(selectedTask);
                    setIsRescheduleOpen(false);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                    selectedTask.status === 'completed'
                      ? 'bg-forest-800 text-sage-300 hover:bg-forest-750'
                      : 'bg-emerald-500 hover:bg-emerald-400 text-forest-950 shadow-sm'
                  }`}
                >
                  {selectedTask.status === 'completed' ? t('পুনরায় সক্রিয় করুন', 'Reopen') : t('সম্পন্ন চিহ্নিত করুন', 'Mark Complete')}
                </button>
              </div>

              {/* Reschedule Form */}
              <form onSubmit={handleRescheduleSubmit} className="space-y-3 pt-2">
                <div className="font-bold text-cream-100 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-gold-400" />
                  <span>{t('নতুন সময়সূচি নির্ধারণ (Reschedule):', 'Reschedule Task Date & Time:')}</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sage-300 mb-1">{t('নতুন তারিখ *', 'New Due Date *')}</label>
                    <input
                      type="date"
                      required
                      value={rescheduleDate}
                      onChange={(e) => setRescheduleDate(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sage-300 mb-1">{t('নতুন সময়', 'New Time')}</label>
                    <input
                      type="time"
                      value={rescheduleTime}
                      onChange={(e) => setRescheduleTime(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                    />
                  </div>
                </div>

                {/* Quick Add Days Shortcuts */}
                <div className="flex items-center gap-2 pt-1">
                  <span className="text-[11px] text-sage-400">{t('দ্রুত পেছান:', 'Quick Postpone:')}</span>
                  <button
                    type="button"
                    onClick={() => {
                      const d = new Date(rescheduleDate || new Date());
                      d.setDate(d.getDate() + 1);
                      setRescheduleDate(formatDateStr(d));
                    }}
                    className="px-2 py-1 rounded-lg bg-forest-800 hover:bg-forest-750 text-[11px] text-sage-300"
                  >
                    +১ দিন (+1 Day)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const d = new Date(rescheduleDate || new Date());
                      d.setDate(d.getDate() + 3);
                      setRescheduleDate(formatDateStr(d));
                    }}
                    className="px-2 py-1 rounded-lg bg-forest-800 hover:bg-forest-750 text-[11px] text-sage-300"
                  >
                    +৩ দিন (+3 Days)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const d = new Date(rescheduleDate || new Date());
                      d.setDate(d.getDate() + 7);
                      setRescheduleDate(formatDateStr(d));
                    }}
                    className="px-2 py-1 rounded-lg bg-forest-800 hover:bg-forest-750 text-[11px] text-sage-300"
                  >
                    +৭ দিন (+7 Days)
                  </button>
                </div>

                <div>
                  <label className="block text-sage-300 mb-1">{t('পুনঃনির্ধারণের কারণ / নোট', 'Reason / Reschedule Note')}</label>
                  <textarea
                    rows={2}
                    placeholder={t('যেমন: ভারী বৃষ্টির কারণে ২ দিন পেছানো হলো', 'e.g. Postponed due to heavy rainfall...')}
                    value={rescheduleNotes}
                    onChange={(e) => setRescheduleNotes(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  />
                </div>

                <div className="pt-3 flex items-center justify-between border-t border-forest-800">
                  <button
                    type="button"
                    onClick={() => handleDeleteTask(selectedTask.id)}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800/60 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{t('কাজ মুছুন', 'Delete Task')}</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIsRescheduleOpen(false)}
                      className="px-4 py-2 rounded-xl bg-forest-900 hover:bg-forest-850 text-sage-300"
                    >
                      {t('বাতিল', 'Cancel')}
                    </button>
                    <button
                      type="submit"
                      disabled={isActionPending}
                      className="px-5 py-2 rounded-xl bg-gold-500 hover:bg-gold-400 text-forest-950 font-bold disabled:opacity-50 cursor-pointer shadow-md"
                    >
                      {isActionPending ? t('পরিবর্তন হচ্ছে...', 'Updating...') : t('পুনঃনির্ধারণ নিশ্চিত করুন', 'Confirm Reschedule')}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 5: SMART AGRICULTURAL SCHEDULE GENERATOR MODAL (Phase F4B)
          ========================================================================= */}
      {isScheduleGenModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-950/80 backdrop-blur-sm animate-fade-in-up font-bengali">
          <div className="bg-forest-950 border border-gold-500/40 rounded-3xl w-full max-w-lg p-6 text-cream-50 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-forest-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gold-400/20 text-gold-400 flex items-center justify-center border border-gold-400/30">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-cream-50">
                    {t('স্মার্ট কৃষি পরিকল্পনা জেনারেটর', 'Smart Crop Schedule Generator')}
                  </h3>
                  <span className="text-[11px] text-sage-300">
                    {t('BRRI / BAMIS / BARI বিজ্ঞানসম্মত গবেষণা মানদণ্ড', 'BRRI / BAMIS / BARI Verified Agricultural Standards')}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsScheduleGenModalOpen(false)}
                className="p-1 rounded-lg hover:bg-forest-850 text-sage-400 hover:text-cream-50"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRunScheduleGenerate} className="space-y-4 pt-4 text-xs">
              {/* Farm Selection */}
              <div>
                <label className="block text-sage-300 font-semibold mb-1">
                  {t('খামার নির্বাচন করুন *', 'Select Farm *')}
                </label>
                <select
                  required
                  value={genForm.farm_id}
                  onChange={(e) => {
                    const fId = Number(e.target.value);
                    const farmCrops = crops.filter((c) => c.farm_id === fId);
                    setGenForm({
                      ...genForm,
                      farm_id: fId,
                      crop_id: farmCrops[0]?.id || 0,
                    });
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                >
                  <option value={0} disabled>{t('-- খামার নির্বাচন করুন --', '-- Select Farm --')}</option>
                  {farms.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name} ({f.district}, {f.division}) - {f.area} {f.area_unit}
                    </option>
                  ))}
                </select>
              </div>

              {/* Crop Selection */}
              <div>
                <label className="block text-sage-300 font-semibold mb-1">
                  {t('ফসল নির্বাচন করুন *', 'Select Crop *')}
                </label>
                <select
                  required
                  value={genForm.crop_id}
                  onChange={(e) => {
                    const cId = Number(e.target.value);
                    const selected = crops.find((c) => c.id === cId);
                    setGenForm({
                      ...genForm,
                      crop_id: cId,
                      variety: selected?.variety || '',
                      season: selected?.season || 'Rabi',
                      planting_date: selected?.sowing_date || genForm.planting_date,
                    });
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                >
                  <option value={0} disabled>{t('-- ফসল নির্বাচন করুন --', '-- Select Crop --')}</option>
                  {crops
                    .filter((c) => genForm.farm_id === 0 || c.farm_id === genForm.farm_id)
                    .map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.crop_name} {c.variety ? `(${c.variety})` : ''} - {c.season}
                      </option>
                    ))}
                </select>
                {crops.filter((c) => genForm.farm_id === 0 || c.farm_id === genForm.farm_id).length === 0 && (
                  <p className="text-[11px] text-amber-300 mt-1">
                    {t('এই খামারে কোনো ফসল যোগ করা হয়নি। আগে ফসল নির্ধারণ করুন।', 'No crops found for this farm. Please add a crop first.')}
                  </p>
                )}
              </div>

              {/* Planting / Sowing Date */}
              <div>
                <label className="block text-sage-300 font-semibold mb-1">
                  {t('বীজ বপন বা চারা রোপণের তারিখ *', 'Sowing or Planting Date *')}
                </label>
                <input
                  type="date"
                  required
                  value={genForm.planting_date}
                  onChange={(e) => setGenForm({ ...genForm, planting_date: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-gold-300 font-mono focus:outline-none focus:border-gold-500"
                />
                <span className="text-[10px] text-sage-400 mt-0.5 block">
                  {t('এই তারিখের ভিত্তিতে বীজতলা, সার প্রয়োগ, সেচ ও ধান কর্তনের দিন গণনা করা হবে।', 'All stage intervals will be scientifically calculated starting from this date.')}
                </span>
              </div>

              {/* Season & Variety (Optional override) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('মৌসুম (Season)', 'Season')}
                  </label>
                  <select
                    value={genForm.season}
                    onChange={(e) => setGenForm({ ...genForm, season: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  >
                    <option value="Rabi">{t('রবি (Rabi / শীতকালীন)', 'Rabi (Winter)')}</option>
                    <option value="Kharif-1">{t('খরিপ-১ (Kharif-1 / আউশ ও গ্রীষ্ম)', 'Kharif-1')}</option>
                    <option value="Kharif-2">{t('খরিপ-২ (Kharif-2 / আমন ও বর্ষা)', 'Kharif-2')}</option>
                    <option value="Year-round">{t('সারাবছর (Year-round)', 'Year-round')}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sage-300 font-semibold mb-1">
                    {t('জাত (Variety)', 'Variety')}
                  </label>
                  <input
                    type="text"
                    placeholder={t('যেমন: ব্রি ধান-২৮, রতন', 'e.g. BRRI Dhan-28, Ratan')}
                    value={genForm.variety}
                    onChange={(e) => setGenForm({ ...genForm, variety: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500"
                  />
                </div>
              </div>

              {/* Provenance note */}
              <div className="p-3 rounded-2xl bg-forest-900/60 border border-forest-800 text-[11px] text-sage-300 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  {t(
                    'পরিকল্পনা তৈরির সাথে সাথেই কোনো টাস্ক ডেটাবেজে সরাসরি জমা হবে না। প্রথমে আপনি প্রিভিউ দেখে সময়সূচি সামঞ্জস্য করতে পারবেন।',
                    'Generates an interactive preview first. No changes are saved to your database until you confirm.'
                  )}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-3 border-t border-forest-800">
                <button
                  type="button"
                  onClick={() => setIsScheduleGenModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-forest-900 hover:bg-forest-850 text-sage-300 cursor-pointer"
                >
                  {t('বাতিল', 'Cancel')}
                </button>
                <button
                  type="submit"
                  disabled={isGeneratingSchedule || !genForm.farm_id || !genForm.crop_id}
                  className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-400 hover:to-gold-500 text-forest-950 font-bold disabled:opacity-50 cursor-pointer shadow-md transition-all"
                >
                  {isGeneratingSchedule ? (
                    <span>{t('গণনা হচ্ছে...', 'Generating...')}</span>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>{t('কৃষি পরিকল্পনা তৈরি করুন', 'Generate Schedule')}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 6: SCHEDULE PREVIEW & CONFIRMATION PANEL (Phase F4B)
          ========================================================================= */}
      {schedulePreview && (
        <SchedulePreviewPanel
          preview={schedulePreview}
          isOpen={isSchedulePreviewOpen}
          onClose={() => setIsSchedulePreviewOpen(false)}
          onConfirm={handleConfirmSchedule}
          isConfirming={isConfirmingSchedule}
        />
      )}

      {/* =========================================================================
          MODAL 7: WEATHER RESCHEDULE MODAL (Phase F4C: FARMER APPROVAL REQUIRED)
          ========================================================================= */}
      {isWeatherRescheduleOpen && selectedWeatherAdvisory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-950/80 backdrop-blur-sm animate-fade-in-up">
          <div className="bg-forest-950 border border-amber-600/60 rounded-3xl w-full max-w-lg p-6 text-cream-50 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-forest-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <CloudRain className="w-4 h-4" />
                </div>
                <h3 className="font-bengali font-bold text-lg text-cream-50">
                  {t('আবহাওয়া সতর্কতায় কাজ পুনর্নির্ধারণ', 'Weather-Aware Task Rescheduling')}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsWeatherRescheduleOpen(false);
                  setSelectedWeatherAdvisory(null);
                }}
                className="p-1 rounded-lg hover:bg-forest-850 text-sage-400 hover:text-cream-50 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 pt-4 text-xs font-bengali">
              {/* Conflict Context Box */}
              <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-600/40 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-300 text-sm">{selectedWeatherAdvisory.title_bn}</span>
                  <span className="px-2 py-0.5 rounded bg-slate-900 text-slate-300 text-[10px]">
                    বর্তমান তারিখ: {selectedWeatherAdvisory.task_due_date}
                  </span>
                </div>
                <p className="text-slate-300 leading-relaxed">{selectedWeatherAdvisory.reason_bn}</p>
                <div className="text-[11px] text-emerald-400 bg-emerald-950/40 p-2 rounded-lg border border-emerald-800/40">
                  💡 পরামর্শ: {selectedWeatherAdvisory.action_suggestion_bn}
                </div>
              </div>

              {/* Task Details */}
              <div className="p-3 bg-forest-900/60 rounded-xl border border-forest-800">
                <span className="text-sage-400 text-[11px]">নির্ধারিত কাজের নাম:</span>
                <div className="text-sm font-bold text-cream-50 mt-0.5">{selectedWeatherAdvisory.task_title}</div>
              </div>

              {/* Quick Shift Days */}
              <div>
                <label className="block text-sage-300 font-semibold mb-2">
                  {t('প্রস্তাবিত দিন পরিবর্তন (এক ক্লিকে):', 'Suggested Date Shift:')}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {selectedWeatherAdvisory.suggested_reschedule_days.map((days) => {
                    const baseDate = new Date(selectedWeatherAdvisory.task_due_date);
                    baseDate.setDate(baseDate.getDate() + days);
                    const shiftedStr = formatDateStr(baseDate);
                    const isSelected = weatherRescheduleDate === shiftedStr;
                    return (
                      <button
                        key={days}
                        type="button"
                        onClick={() => setWeatherRescheduleDate(shiftedStr)}
                        className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-400 text-amber-200 font-bold shadow'
                            : 'bg-forest-900 border-forest-750 text-sage-300 hover:bg-forest-850'
                        }`}
                      >
                        <div className="text-xs">+{toBnDigits(days)} দিন</div>
                        <div className="text-[10px] text-slate-400 mt-0.5">{shiftedStr}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Custom Date Input */}
              <div>
                <label className="block text-sage-300 font-semibold mb-1">
                  {t('অথবা নির্দিষ্ট নতুন তারিখ নির্ধারণ করুন:', 'Or Pick Custom Date:')}
                </label>
                <input
                  type="date"
                  value={weatherRescheduleDate}
                  onChange={(e) => setWeatherRescheduleDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-forest-900 border border-forest-750 text-cream-50 focus:outline-none focus:border-gold-500 font-mono"
                />
              </div>

              {/* Uncertainty & Autonomy Note */}
              <div className="text-[10px] text-slate-400 italic bg-forest-900/40 p-2.5 rounded-xl border border-forest-800">
                ⚠️ কৃষকের স্পষ্ট অনুমোদন ব্যতিরেকে স্বয়ংক্রিয়ভাবে কোনো তারিখ পরিবর্তিত হয় না। "পরিবর্তন নিশ্চিত করুন" বাটনে ক্লিক করলে আপনার ক্যালেন্ডারে নতুন তারিখটি সংরক্ষিত হবে।
              </div>

              {/* Buttons */}
              <div className="pt-3 flex items-center justify-end gap-3 border-t border-forest-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsWeatherRescheduleOpen(false);
                    setSelectedWeatherAdvisory(null);
                  }}
                  className="px-4 py-2 rounded-xl bg-forest-900 hover:bg-forest-850 text-sage-300 cursor-pointer"
                >
                  {t('বাতিল', 'Cancel')}
                </button>
                <button
                  type="button"
                  disabled={isReschedulingWeather || !weatherRescheduleDate}
                  onClick={async () => {
                    setIsReschedulingWeather(true);
                    try {
                      await calendarApi.updateTask(selectedWeatherAdvisory.task_id, {
                        due_date: weatherRescheduleDate,
                        notes: `[আবহাওয়া সতর্কতায় পুনর্নির্ধারিত] পূর্বের তারিখ: ${selectedWeatherAdvisory.task_due_date}`,
                      });
                      setSuccessMessage(
                        t(
                          `কাজটি সফলভাবে ${weatherRescheduleDate} তারিখে পুনর্নির্ধারণ করা হয়েছে।`,
                          `Task successfully rescheduled to ${weatherRescheduleDate}.`
                        )
                      );
                      setIsWeatherRescheduleOpen(false);
                      setSelectedWeatherAdvisory(null);
                      await loadAllData();
                    } catch (err) {
                      setErrorMessage(getErrorMessage(err));
                    } finally {
                      setIsReschedulingWeather(false);
                    }
                  }}
                  className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold disabled:opacity-50 cursor-pointer shadow-md transition-all"
                >
                  {isReschedulingWeather ? (
                    <span>{t('সংরক্ষণ হচ্ছে...', 'Saving...')}</span>
                  ) : (
                    <>
                      <CalendarIcon className="w-4 h-4" />
                      <span>{t('পরিবর্তন নিশ্চিত করুন', 'Confirm Reschedule')}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Subcomponent: Task Card for Agenda & List View
interface TaskCardProps {
  task: CalendarTask;
  onToggleStatus: () => void;
  onReschedule: () => void;
  onDelete: () => void;
  t: (bn: string, en: string) => string;
  lang: string;
}

function TaskCard({ task, onToggleStatus, onReschedule, onDelete, t, lang }: TaskCardProps) {
  const isDone = task.status === 'completed';
  const meta = TASK_CATEGORIES.find((c) => c.id === task.category) || TASK_CATEGORIES[TASK_CATEGORIES.length - 1];

  return (
    <div
      className={`p-4 rounded-2xl border transition-all text-xs font-bengali space-y-2.5 ${
        isDone
          ? 'bg-forest-950/60 border-forest-800/80 text-sage-400'
          : task.is_overdue
          ? 'bg-rose-950/40 border-rose-600/50 text-rose-100 shadow-md'
          : 'bg-forest-950 border-forest-800 text-cream-100 shadow-sm hover:border-gold-400/40'
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-2.5 flex-1">
          <button
            type="button"
            onClick={onToggleStatus}
            aria-label={isDone ? 'Mark as pending' : 'Mark as complete'}
            className="mt-0.5 text-sage-400 hover:text-emerald-400 cursor-pointer transition-colors"
          >
            {isDone ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <Circle className="w-4 h-4" />
            )}
          </button>

          <div>
            <div className="flex flex-wrap items-center gap-1.5 mb-1">
              {task.is_generated && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-gold-400/20 text-gold-300 border border-gold-400/30">
                  <Sparkles className="w-3 h-3 text-gold-400" />
                  <span>{t('AI স্মার্ট পরিকল্পনা', 'AI Schedule')}</span>
                </span>
              )}
              {task.source_org && (
                <span className="px-1.5 py-0.2 rounded text-[9px] font-mono bg-forest-850 text-emerald-300 border border-emerald-500/20">
                  {task.source_org}
                </span>
              )}
            </div>
            <h4 className={`font-bold text-sm sm:text-base text-cream-50 ${isDone ? 'line-through text-sage-400' : ''}`}>
              {task.title}
            </h4>
            <div className="flex flex-wrap items-center gap-2 text-[11px] text-sage-400 mt-1">
              <span className="inline-flex items-center gap-1">
                <MapPin className="w-3 h-3 text-gold-400" />
                {task.farm_name || `খামার #${task.farm_id}`}
              </span>
              {task.crop_name && (
                <span className="inline-flex items-center gap-1">
                  <Layers className="w-3 h-3 text-emerald-400" />
                  {task.crop_name}
                </span>
              )}
            </div>
          </div>
        </div>

        <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${meta.color}`}>
          {lang === 'bn' ? meta.labelBn : meta.labelEn}
        </span>
      </div>

      {task.notes && (
        <p className="text-[11px] text-sage-300 bg-forest-900/60 p-2 rounded-xl border border-forest-800/60 leading-relaxed">
          {task.notes}
        </p>
      )}

      <div className="flex items-center justify-between pt-2 border-t border-forest-800/60 text-[11px]">
        <div className="flex items-center gap-2">
          <span className="font-mono text-gold-300 font-semibold">{task.due_date}</span>
          {task.due_time && <span className="text-sage-400 font-mono">({task.due_time})</span>}
          {task.is_overdue && !isDone && (
            <span className="px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 text-[10px] font-bold">
              {t('মেয়াদোত্তীর্ণ', 'Overdue')}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={onReschedule}
            className="px-2.5 py-1 rounded-lg bg-forest-850 hover:bg-forest-800 text-gold-300 text-[11px] transition-colors cursor-pointer"
          >
            {t('পুনঃনির্ধারণ', 'Reschedule')}
          </button>
          <button
            type="button"
            onClick={onDelete}
            title={t('কাজ মুছুন', 'Delete')}
            className="p-1 rounded-lg hover:bg-rose-950/60 text-sage-400 hover:text-rose-400 transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
